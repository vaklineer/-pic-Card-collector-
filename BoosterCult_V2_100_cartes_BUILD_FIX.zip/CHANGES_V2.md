# Changements V2

## Images
Le prototype affichait souvent un bloc gris "Wikipédia". La V2 ne dépend plus d'une URL d'image figée : elle demande d'abord la miniature de l'article à l'API Wikipédia française, puis bascule automatiquement vers une recherche de média sur Wikimedia Commons si nécessaire. Les URLs valides sont mises en cache. Un bouton « Réparer le cache images » est disponible dans Infos.

## Ergonomie
Les cartes passent à un ratio de carte à collectionner, avec coins arrondis, hiérarchie plus nette et fiche plein écran. Les filtres sont horizontaux et la collection utilise une grille mobile à 2 colonnes.

## Holos
- Standard : aucun bonus.
- Argent : reflet métallique, puissance ×1,08.
- Prisme : bandes colorées, puissance ×1,16.
- Galaxie : voile cosmique et étoiles, puissance ×1,28.
- Aurore : effet multicolore premium, puissance ×1,45.

Les variantes sont aussi identifiables par un badge explicite sur chaque carte.

## Android
L'application utilise `react-native-safe-area-context` et calcule la hauteur réelle de la barre inférieure avec `insets.bottom`. Les menus ne sont donc plus masqués par les boutons de navigation Android.


## Build fix
- React aligné sur 19.2.3 pour React Native 0.86.0 afin de corriger le conflit npm ERESOLVE dans GitHub Actions.
