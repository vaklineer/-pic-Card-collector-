
import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Modal,
  Pressable,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { CARDS, CARDS_BY_ID } from './src/data/cards';
import { CardBack, CardDetails, CardFront } from './src/components/CardView';
import { COLORS, CONDITIONS, RARITIES, VARIANTS } from './src/theme';
import { defaultState, loadState, resetState, saveState } from './src/services/storage';
import { makeInstance, openBooster, randomStat, rollCardByRarity } from './src/services/random';

const BOOSTER_COST = 100;
const TABS = [
  ['home', '⌂', 'Accueil'],
  ['open', '✦', 'Ouvrir'],
  ['collection', '▦', 'Collection'],
  ['play', '⚔', 'Jouer'],
  ['info', 'ⓘ', 'Infos'],
];

const rarityRank = { common: 1, uncommon: 2, rare: 3, epic: 4, legendary: 5, cursed: 6 };

function money(n) {
  return new Intl.NumberFormat('fr-FR').format(n);
}

export default function App() {
  const [tab, setTab] = useState('home');
  const [state, setState] = useState(defaultState);
  const [ready, setReady] = useState(false);
  const [pack, setPack] = useState(null);
  const [revealIndex, setRevealIndex] = useState(0);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    loadState().then((s) => {
      setState(s);
      setReady(true);
    });
  }, []);

  useEffect(() => {
    if (ready) saveState(state);
  }, [state, ready]);

  const openPack = (free = false) => {
    if (!free && state.coins < BOOSTER_COST) return;
    const pulls = openBooster();
    setState((s) => ({
      ...s,
      coins: free ? s.coins : s.coins - BOOSTER_COST,
      collection: [...s.collection, ...pulls],
      boostersOpened: s.boostersOpened + 1,
    }));
    setPack(pulls);
    setRevealIndex(0);
  };

  const openStarter = () => {
    const pulls = openBooster();
    setState((s) => ({
      ...s,
      collection: [...s.collection, ...pulls],
      boostersOpened: s.boostersOpened + 1,
    }));
    setPack(pulls);
    setRevealIndex(0);
  };

  const ownedUnique = useMemo(
    () => new Set(state.collection.map((i) => i.cardId)).size,
    [state.collection]
  );
  const collectionValue = useMemo(
    () => state.collection.reduce((sum, i) => sum + (i.value || 0), 0),
    [state.collection]
  );

  if (!ready) {
    return (
      <SafeAreaView style={styles.loading}>
        <StatusBar barStyle="light-content" />
        <ActivityIndicator size="large" color={COLORS.accent} />
        <Text style={styles.loadingText}>Préparation du classeur de cartes…</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.app}>
      <StatusBar barStyle="light-content" />
      <Header coins={state.coins} unique={ownedUnique} />
      <View style={styles.content}>
        {tab === 'home' && (
          <Home
            state={state}
            ownedUnique={ownedUnique}
            collectionValue={collectionValue}
            onOpen={() => setTab('open')}
            onPlay={() => setTab('play')}
            onCollection={() => setTab('collection')}
          />
        )}
        {tab === 'open' && (
          <OpenScreen
            state={state}
            onOpen={() => openPack(false)}
            onStarter={openStarter}
          />
        )}
        {tab === 'collection' && (
          <CollectionScreen
            state={state}
            onSelect={(card, instance) => setSelected({ card, instance })}
          />
        )}
        {tab === 'play' && (
          <PlayScreen
            state={state}
            onResult={(won) =>
              setState((s) => ({
                ...s,
                coins: s.coins + (won ? 60 : 20),
                wins: s.wins + (won ? 1 : 0),
                losses: s.losses + (won ? 0 : 1),
              }))
            }
            goOpen={() => setTab('open')}
          />
        )}
        {tab === 'info' && (
          <InfoScreen
            state={state}
            onReset={async () => {
              await resetState();
              setState(defaultState);
              setTab('home');
            }}
          />
        )}
      </View>

      <BottomNav tab={tab} setTab={setTab} />

      <Modal visible={!!pack} animationType="slide" transparent={false} onRequestClose={() => setPack(null)}>
        <SafeAreaView style={styles.modalScreen}>
          {pack && (
            <RevealPack
              pack={pack}
              index={revealIndex}
              setIndex={setRevealIndex}
              onClose={() => setPack(null)}
            />
          )}
        </SafeAreaView>
      </Modal>

      <Modal visible={!!selected} animationType="slide" transparent onRequestClose={() => setSelected(null)}>
        <View style={styles.modalBackdrop}>
          <ScrollView contentContainerStyle={styles.detailModalScroll}>
            <View style={styles.detailModalCard}>
              {selected && (
                <CardDetails
                  card={selected.card}
                  instance={selected.instance}
                  onClose={() => setSelected(null)}
                />
              )}
            </View>
          </ScrollView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function Header({ coins, unique }) {
  return (
    <View style={styles.header}>
      <View>
        <Text style={styles.brand}>BOOSTER CULT</Text>
        <Text style={styles.brandSub}>Série 001 · Le Grand Bazar</Text>
      </View>
      <View style={styles.headerStats}>
        <View style={styles.pill}><Text style={styles.pillText}>◈ {money(coins)}</Text></View>
        <View style={styles.pill}><Text style={styles.pillText}>{unique}/100</Text></View>
      </View>
    </View>
  );
}

function Home({ state, ownedUnique, collectionValue, onOpen, onPlay, onCollection }) {
  const best = useMemo(() => {
    if (!state.collection.length) return null;
    return [...state.collection].sort((a, b) => b.value - a.value)[0];
  }, [state.collection]);

  return (
    <ScrollView contentContainerStyle={styles.scrollPad}>
      <View style={styles.hero}>
        <Text style={styles.heroEyebrow}>COLLECTION · DUELS · ABSURDITÉS</Text>
        <Text style={styles.heroTitle}>Des vraies références.{'\n'}Des cartes pas tout à fait normales.</Text>
        <Text style={styles.heroBody}>
          100 cartes de départ, illustrées via Wikipédia/Wikimedia. Rareté, finition et état sont tirés séparément.
        </Text>
        <Pressable style={styles.primaryButton} onPress={onOpen}>
          <Text style={styles.primaryButtonText}>OUVRIR UN BOOSTER</Text>
          <Text style={styles.primaryButtonSub}>5 cartes · Rare ou mieux garantie</Text>
        </Pressable>
      </View>

      <View style={styles.metricsRow}>
        <Metric value={`${ownedUnique}/100`} label="découvertes" />
        <Metric value={`${state.collection.length}`} label="cartes possédées" />
        <Metric value={`${money(collectionValue)} C`} label="cote totale" />
      </View>

      <Text style={styles.sectionTitle}>Ton meilleur tirage</Text>
      {best ? (
        <View style={styles.featureCard}>
          <CardFront card={CARDS_BY_ID[best.cardId]} instance={best} />
        </View>
      ) : (
        <View style={styles.emptyBox}>
          <Text style={styles.emptyTitle}>Album vide</Text>
          <Text style={styles.emptyText}>Ton premier booster découverte est gratuit.</Text>
        </View>
      )}

      <View style={styles.twoButtons}>
        <Pressable style={styles.secondaryButton} onPress={onPlay}><Text style={styles.secondaryButtonText}>⚔ JOUER</Text></Pressable>
        <Pressable style={styles.secondaryButton} onPress={onCollection}><Text style={styles.secondaryButtonText}>▦ COLLECTION</Text></Pressable>
      </View>
    </ScrollView>
  );
}

function Metric({ value, label }) {
  return (
    <View style={styles.metric}>
      <Text style={styles.metricValue}>{value}</Text>
      <Text style={styles.metricLabel}>{label}</Text>
    </View>
  );
}

function OpenScreen({ state, onOpen, onStarter }) {
  const hasCards = state.collection.length > 0;
  return (
    <ScrollView contentContainerStyle={styles.scrollPad}>
      <Text style={styles.pageTitle}>Booster Série 001</Text>
      <Text style={styles.pageSubtitle}>Le Grand Bazar · 100 cartes</Text>

      <View style={styles.packArt}>
        <Text style={styles.packMini}>BOOSTER CULT</Text>
        <Text style={styles.packBig}>LE GRAND{'\n'}BAZAR</Text>
        <Text style={styles.packQuestion}>?</Text>
        <Text style={styles.packDetails}>5 CARTES · 1 RARE+ GARANTIE</Text>
      </View>

      {!hasCards && (
        <Pressable style={styles.starterButton} onPress={onStarter}>
          <Text style={styles.starterTitle}>BOOSTER DÉCOUVERTE · GRATUIT</Text>
          <Text style={styles.starterText}>Pour lancer ta collection.</Text>
        </Pressable>
      )}

      <Pressable
        style={[styles.primaryButton, state.coins < BOOSTER_COST && styles.buttonDisabled]}
        disabled={state.coins < BOOSTER_COST}
        onPress={onOpen}
      >
        <Text style={styles.primaryButtonText}>OUVRIR · {BOOSTER_COST} C</Text>
        <Text style={styles.primaryButtonSub}>Solde : {money(state.coins)} C</Text>
      </Pressable>

      <Text style={styles.sectionTitle}>Probabilités de rareté</Text>
      <View style={styles.oddsBox}>
        {Object.entries(RARITIES).map(([key, r]) => (
          <View key={key} style={styles.oddsRow}>
            <View style={[styles.dot, { backgroundColor: r.color }]} />
            <Text style={styles.oddsLabel}>{r.label}</Text>
            <Text style={styles.oddsValue}>{r.weight}%</Text>
          </View>
        ))}
      </View>

      <Text style={styles.sectionTitle}>Finitions indépendantes</Text>
      <View style={styles.chips}>
        {Object.entries(VARIANTS).map(([key, v]) => (
          <View key={key} style={styles.chip}><Text style={styles.chipText}>{v.label} · {v.weight}%</Text></View>
        ))}
      </View>

      <Text style={styles.smallNote}>
        L’état physique est également tiré séparément. Une carte rare peut être abîmée ; une commune impeccable peut prendre une petite surcote.
      </Text>
    </ScrollView>
  );
}

function RevealPack({ pack, index, setIndex, onClose }) {
  const instance = pack[index];
  const card = CARDS_BY_ID[instance.cardId];
  const rarity = RARITIES[card.rarity];
  const variant = VARIANTS[instance.variant];
  const condition = CONDITIONS[instance.condition];
  const isLast = index === pack.length - 1;

  return (
    <ScrollView contentContainerStyle={styles.reveal}>
      <Text style={styles.revealCounter}>CARTE {index + 1} / {pack.length}</Text>
      <Text style={[styles.revealRarity, { color: rarity.color }]}>
        {rarity.label} · {variant.label.toUpperCase()}
      </Text>

      <View style={styles.revealCard}>
        <CardFront card={card} instance={instance} />
      </View>

      <View style={styles.revealGrade}>
        <Text style={styles.revealGradeLabel}>ÉTAT</Text>
        <Text style={styles.revealGradeValue}>{condition.label}</Text>
        <Text style={styles.revealGradePrice}>Cote estimée : {instance.value} C · ×{condition.multiplier.toFixed(2)}</Text>
      </View>

      <Pressable
        style={styles.primaryButton}
        onPress={() => {
          if (isLast) onClose();
          else setIndex(index + 1);
        }}
      >
        <Text style={styles.primaryButtonText}>{isLast ? 'AJOUTÉES À LA COLLECTION' : 'CARTE SUIVANTE'}</Text>
      </Pressable>
    </ScrollView>
  );
}

function CollectionScreen({ state, onSelect }) {
  const [search, setSearch] = useState('');
  const [rarity, setRarity] = useState('all');

  const grouped = useMemo(() => {
    const map = {};
    state.collection.forEach((inst) => {
      if (!map[inst.cardId]) map[inst.cardId] = [];
      map[inst.cardId].push(inst);
    });
    return map;
  }, [state.collection]);

  const cards = useMemo(() => {
    const q = search.trim().toLowerCase();
    return CARDS.filter((c) => {
      if (rarity !== 'all' && c.rarity !== rarity) return false;
      if (q && !`${c.name} ${c.category}`.toLowerCase().includes(q)) return false;
      return true;
    }).sort((a, b) => {
      const aOwn = grouped[a.id]?.length || 0;
      const bOwn = grouped[b.id]?.length || 0;
      if (!!aOwn !== !!bOwn) return bOwn - aOwn;
      return a.number - b.number;
    });
  }, [search, rarity, grouped]);

  return (
    <View style={styles.collectionPage}>
      <TextInput
        value={search}
        onChangeText={setSearch}
        placeholder="Rechercher une carte…"
        placeholderTextColor="#6F788B"
        style={styles.search}
      />
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>
        <Filter active={rarity === 'all'} label="Toutes" onPress={() => setRarity('all')} />
        {Object.entries(RARITIES).map(([key, r]) => (
          <Filter key={key} active={rarity === key} label={r.label} onPress={() => setRarity(key)} color={r.color} />
        ))}
      </ScrollView>

      <FlatList
        data={cards}
        keyExtractor={(item) => item.id}
        numColumns={2}
        contentContainerStyle={styles.grid}
        columnWrapperStyle={styles.gridRow}
        renderItem={({ item }) => {
          const owned = grouped[item.id] || [];
          const best = owned.length ? [...owned].sort((a,b) => b.value - a.value)[0] : null;
          const displayInst = best || {
            instanceId: `locked-${item.id}`,
            cardId: item.id,
            variant: 'standard',
            condition: 'excellent',
            value: item.baseValue,
          };
          return (
            <View style={[styles.gridCard, !best && styles.lockedCard]}>
              <CardFront
                card={item}
                instance={displayInst}
                compact
                onPress={best ? () => onSelect(item, best) : undefined}
              />
              <View style={styles.gridMeta}>
                <Text style={styles.gridCount}>{best ? `×${owned.length}` : 'NON TROUVÉE'}</Text>
                {best && <Text style={styles.gridBest}>meilleure {best.value} C</Text>}
              </View>
            </View>
          );
        }}
      />
    </View>
  );
}

function Filter({ active, label, onPress, color }) {
  return (
    <Pressable
      onPress={onPress}
      style={[
        styles.filter,
        active && { backgroundColor: color || '#EEE', borderColor: color || '#EEE' },
      ]}
    >
      <Text style={[styles.filterText, active && { color: '#0A0B0E' }]}>{label}</Text>
    </Pressable>
  );
}

function PlayScreen({ state, onResult, goOpen }) {
  const [match, setMatch] = useState(null);

  const start = () => {
    if (state.collection.length < 3) return;
    const shuffled = [...state.collection].sort(() => Math.random() - 0.5).slice(0, 3);
    setMatch({
      player: shuffled,
      round: 0,
      playerScore: 0,
      cpuScore: 0,
      history: [],
      finished: false,
    });
  };

  const nextRound = () => {
    if (!match || match.finished) return;
    const idx = match.round;
    const stat = randomStat();
    const pInst = match.player[idx];
    const pCard = CARDS_BY_ID[pInst.cardId];
    const cpuCard = rollCardByRarity();
    const cpuInst = makeInstance(cpuCard, { variant: 'standard', condition: 'excellent' });
    const pScore = pCard[stat];
    const cScore = cpuCard[stat];
    const win = pScore >= cScore;
    const nextPlayer = match.playerScore + (win ? 1 : 0);
    const nextCpu = match.cpuScore + (win ? 0 : 1);
    const nextRoundIndex = idx + 1;
    const finished = nextRoundIndex >= 3;
    const next = {
      ...match,
      round: nextRoundIndex,
      playerScore: nextPlayer,
      cpuScore: nextCpu,
      history: [...match.history, { stat, pCard, pInst, cpuCard, cpuInst, pScore, cScore, win }],
      finished,
    };
    setMatch(next);
    if (finished) onResult(nextPlayer >= nextCpu);
  };

  if (state.collection.length < 3) {
    return (
      <View style={styles.centerPage}>
        <Text style={styles.pageTitle}>Il te faut 3 cartes</Text>
        <Text style={styles.pageSubtitle}>Ouvre ton premier booster pour jouer.</Text>
        <Pressable style={styles.primaryButton} onPress={goOpen}><Text style={styles.primaryButtonText}>OUVRIR UN BOOSTER</Text></Pressable>
      </View>
    );
  }

  if (!match) {
    return (
      <ScrollView contentContainerStyle={styles.scrollPad}>
        <Text style={styles.pageTitle}>Duel express</Text>
        <Text style={styles.pageSubtitle}>3 manches. Une stat tirée au hasard. La meilleure valeur gagne.</Text>
        <View style={styles.rulesBox}>
          <Text style={styles.rulesTitle}>RÈGLE V1</Text>
          <Text style={styles.rulesText}>
            Tes finitions et l’état n’augmentent pas la puissance : ils influencent uniquement la collection et la cote. Donc pas de pay-to-win.
          </Text>
        </View>
        <Pressable style={styles.primaryButton} onPress={start}><Text style={styles.primaryButtonText}>LANCER UN DUEL</Text><Text style={styles.primaryButtonSub}>Victoire +60 C · Défaite +20 C</Text></Pressable>
        <Text style={styles.record}>Bilan : {state.wins} victoire(s) · {state.losses} défaite(s)</Text>
      </ScrollView>
    );
  }

  const last = match.history[match.history.length - 1];

  return (
    <ScrollView contentContainerStyle={styles.scrollPad}>
      <View style={styles.scoreBoard}>
        <Text style={styles.scoreName}>TOI</Text>
        <Text style={styles.score}>{match.playerScore} — {match.cpuScore}</Text>
        <Text style={styles.scoreName}>BOT</Text>
      </View>

      {last ? (
        <View>
          <Text style={styles.roundTitle}>Manche {match.history.length} · {last.stat.toUpperCase()}</Text>
          <View style={styles.battleRow}>
            <View style={styles.battleCard}>
              <CardFront card={last.pCard} instance={last.pInst} compact />
              <Text style={styles.battleScore}>{last.pScore}</Text>
            </View>
            <Text style={styles.vs}>VS</Text>
            <View style={styles.battleCard}>
              <CardFront card={last.cpuCard} instance={last.cpuInst} compact />
              <Text style={styles.battleScore}>{last.cScore}</Text>
            </View>
          </View>
          <Text style={[styles.roundResult, { color: last.win ? '#69D58C' : '#FF6F7C' }]}>
            {last.win ? 'MANCHE GAGNÉE' : 'MANCHE PERDUE'}
          </Text>
        </View>
      ) : (
        <View style={styles.readyDuel}>
          <Text style={styles.readyDuelText}>Tes 3 cartes sont prêtes.</Text>
        </View>
      )}

      {!match.finished ? (
        <Pressable style={styles.primaryButton} onPress={nextRound}>
          <Text style={styles.primaryButtonText}>{match.round === 0 ? 'JOUER LA 1re MANCHE' : 'MANCHE SUIVANTE'}</Text>
        </Pressable>
      ) : (
        <>
          <Text style={styles.finalResult}>{match.playerScore >= match.cpuScore ? '🏆 VICTOIRE' : '☠ DÉFAITE'}</Text>
          <Pressable style={styles.primaryButton} onPress={start}><Text style={styles.primaryButtonText}>REJOUER</Text></Pressable>
        </>
      )}
    </ScrollView>
  );
}

function InfoScreen({ state, onReset }) {
  return (
    <ScrollView contentContainerStyle={styles.scrollPad}>
      <Text style={styles.pageTitle}>Prototype V1</Text>
      <Text style={styles.pageSubtitle}>Base jouable pour tester la boucle collection → booster → duel.</Text>

      <InfoBox title="100 cartes intégrées">
        Les sujets, noms, raretés, catégories, textes et statistiques sont stockés directement dans src/data/cards.js.
      </InfoBox>
      <InfoBox title="Images réelles">
        Les visuels sont demandés à Wikipédia en français. Quand le fichier provient de Wikimedia Commons, la fiche tente également de charger l’auteur, la licence et le lien du fichier.
      </InfoBox>
      <InfoBox title="État & cote">
        Impeccable, Quasi neuve, Bien conservée, Usée, Abîmée ou Massacrée. Le dos montre progressivement les marques d’usure. L’état modifie la cote, jamais les stats de combat.
      </InfoBox>
      <InfoBox title="Variantes">
        Standard, Holo, Full Art, Gold, Glitch et Numérotée /250. Les variantes sont indépendantes de la rareté.
      </InfoBox>

      <Text style={styles.debugText}>Boosters ouverts : {state.boostersOpened}</Text>
      <Pressable style={styles.dangerButton} onPress={onReset}>
        <Text style={styles.dangerButtonText}>RÉINITIALISER LA SAUVEGARDE LOCALE</Text>
      </Pressable>
    </ScrollView>
  );
}

function InfoBox({ title, children }) {
  return (
    <View style={styles.infoBox}>
      <Text style={styles.infoTitle}>{title}</Text>
      <Text style={styles.infoText}>{children}</Text>
    </View>
  );
}

function BottomNav({ tab, setTab }) {
  return (
    <View style={styles.nav}>
      {TABS.map(([key, icon, label]) => (
        <Pressable key={key} style={styles.navItem} onPress={() => setTab(key)}>
          <Text style={[styles.navIcon, tab === key && styles.navActive]}>{icon}</Text>
          <Text style={[styles.navLabel, tab === key && styles.navActive]}>{label}</Text>
        </Pressable>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  app: { flex: 1, backgroundColor: COLORS.bg },
  loading: { flex: 1, backgroundColor: COLORS.bg, alignItems: 'center', justifyContent: 'center', gap: 14 },
  loadingText: { color: COLORS.muted, fontWeight: '700' },
  content: { flex: 1 },
  header: { minHeight: 72, paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderColor: COLORS.line, backgroundColor: '#0E1118', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  brand: { color: '#FFF', fontSize: 19, fontWeight: '900', letterSpacing: 1 },
  brandSub: { color: COLORS.muted, fontSize: 9, marginTop: 2, fontWeight: '700' },
  headerStats: { flexDirection: 'row', gap: 7 },
  pill: { paddingHorizontal: 9, paddingVertical: 6, borderRadius: 10, backgroundColor: COLORS.panel2, borderWidth: 1, borderColor: COLORS.line },
  pillText: { color: '#FFF', fontWeight: '900', fontSize: 11 },
  scrollPad: { padding: 16, paddingBottom: 38 },
  hero: { backgroundColor: '#171A26', borderWidth: 1, borderColor: '#343B50', borderRadius: 22, padding: 18, overflow: 'hidden' },
  heroEyebrow: { color: COLORS.accent, fontWeight: '900', letterSpacing: 1.3, fontSize: 10 },
  heroTitle: { color: '#FFF', fontWeight: '900', fontSize: 29, lineHeight: 33, marginTop: 10 },
  heroBody: { color: COLORS.muted, fontSize: 13, lineHeight: 19, marginTop: 10, marginBottom: 18 },
  primaryButton: { backgroundColor: COLORS.accent, paddingVertical: 14, paddingHorizontal: 16, borderRadius: 14, alignItems: 'center', marginTop: 12 },
  primaryButtonText: { color: '#111', fontWeight: '900', fontSize: 14, letterSpacing: .5 },
  primaryButtonSub: { color: '#5A4510', fontSize: 10, fontWeight: '800', marginTop: 2 },
  buttonDisabled: { opacity: .35 },
  metricsRow: { flexDirection: 'row', gap: 8, marginTop: 12 },
  metric: { flex: 1, backgroundColor: COLORS.panel, borderWidth: 1, borderColor: COLORS.line, borderRadius: 14, padding: 10 },
  metricValue: { color: '#FFF', fontWeight: '900', fontSize: 15 },
  metricLabel: { color: COLORS.muted, fontSize: 9, marginTop: 3 },
  sectionTitle: { color: '#FFF', fontWeight: '900', fontSize: 15, marginTop: 22, marginBottom: 10 },
  featureCard: { width: '86%', alignSelf: 'center' },
  emptyBox: { borderWidth: 1, borderStyle: 'dashed', borderColor: '#3E4659', borderRadius: 16, alignItems: 'center', padding: 26 },
  emptyTitle: { color: '#FFF', fontWeight: '900' },
  emptyText: { color: COLORS.muted, marginTop: 4, textAlign: 'center' },
  twoButtons: { flexDirection: 'row', gap: 10, marginTop: 14 },
  secondaryButton: { flex: 1, backgroundColor: COLORS.panel2, borderWidth: 1, borderColor: COLORS.line, borderRadius: 13, paddingVertical: 12, alignItems: 'center' },
  secondaryButtonText: { color: '#FFF', fontWeight: '900', fontSize: 12 },
  pageTitle: { color: '#FFF', fontSize: 25, fontWeight: '900' },
  pageSubtitle: { color: COLORS.muted, marginTop: 4, fontSize: 12, lineHeight: 18 },
  packArt: { height: 330, borderRadius: 26, borderWidth: 2, borderColor: '#9D62FF', backgroundColor: '#2A184B', marginTop: 18, alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  packMini: { color: '#F7B843', fontWeight: '900', letterSpacing: 2, fontSize: 13 },
  packBig: { color: '#FFF', fontWeight: '900', fontSize: 40, lineHeight: 40, textAlign: 'center', marginTop: 8 },
  packQuestion: { color: '#D8B9FF', fontWeight: '900', fontSize: 95, lineHeight: 105 },
  packDetails: { color: '#CDBBE8', fontWeight: '800', fontSize: 11, letterSpacing: 1 },
  starterButton: { backgroundColor: '#19372A', borderWidth: 1, borderColor: '#4AB477', borderRadius: 14, padding: 14, marginTop: 14 },
  starterTitle: { color: '#6CE59A', fontWeight: '900', fontSize: 12 },
  starterText: { color: '#B7CEBF', fontSize: 10, marginTop: 3 },
  oddsBox: { backgroundColor: COLORS.panel, borderRadius: 14, borderWidth: 1, borderColor: COLORS.line, overflow: 'hidden' },
  oddsRow: { flexDirection: 'row', alignItems: 'center', padding: 11, borderBottomWidth: 1, borderColor: '#242B3B' },
  dot: { width: 10, height: 10, borderRadius: 5, marginRight: 9 },
  oddsLabel: { color: '#FFF', fontWeight: '800', fontSize: 11, flex: 1 },
  oddsValue: { color: COLORS.muted, fontWeight: '900', fontSize: 11 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  chip: { borderWidth: 1, borderColor: '#3B4355', backgroundColor: '#171B25', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 7 },
  chipText: { color: '#DCE2EE', fontSize: 10, fontWeight: '800' },
  smallNote: { color: COLORS.muted, fontSize: 10, lineHeight: 16, marginTop: 16, fontStyle: 'italic' },
  modalScreen: { flex: 1, backgroundColor: COLORS.bg },
  reveal: { padding: 18, paddingBottom: 40 },
  revealCounter: { textAlign: 'center', color: COLORS.muted, fontSize: 11, fontWeight: '900', letterSpacing: 1.5 },
  revealRarity: { textAlign: 'center', marginTop: 4, marginBottom: 12, fontWeight: '900', fontSize: 15 },
  revealCard: { width: '92%', alignSelf: 'center' },
  revealGrade: { backgroundColor: COLORS.panel, borderRadius: 13, borderWidth: 1, borderColor: COLORS.line, alignItems: 'center', padding: 12, marginTop: 14 },
  revealGradeLabel: { color: COLORS.muted, fontSize: 9, letterSpacing: 1.3, fontWeight: '900' },
  revealGradeValue: { color: '#FFF', fontSize: 18, fontWeight: '900', marginTop: 2 },
  revealGradePrice: { color: COLORS.accent, fontSize: 10, fontWeight: '800', marginTop: 4 },
  collectionPage: { flex: 1 },
  search: { margin: 12, marginBottom: 6, backgroundColor: COLORS.panel, borderRadius: 13, borderWidth: 1, borderColor: COLORS.line, paddingHorizontal: 13, paddingVertical: 10, color: '#FFF', fontWeight: '700' },
  filterRow: { paddingHorizontal: 12, paddingVertical: 8, gap: 7 },
  filter: { borderWidth: 1, borderColor: '#384052', backgroundColor: '#141821', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 7 },
  filterText: { color: '#C2CAD8', fontSize: 9, fontWeight: '900' },
  grid: { padding: 8, paddingBottom: 35 },
  gridRow: { gap: 8 },
  gridCard: { flex: 1, marginBottom: 9 },
  lockedCard: { opacity: .34 },
  gridMeta: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 2, paddingTop: 5 },
  gridCount: { color: '#FFF', fontWeight: '900', fontSize: 9 },
  gridBest: { color: COLORS.muted, fontWeight: '700', fontSize: 8 },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,.86)' },
  detailModalScroll: { padding: 18, justifyContent: 'center', minHeight: '100%' },
  detailModalCard: { width: '100%', maxWidth: 460, alignSelf: 'center' },
  centerPage: { flex: 1, justifyContent: 'center', padding: 20 },
  rulesBox: { marginTop: 18, backgroundColor: COLORS.panel, borderRadius: 15, borderWidth: 1, borderColor: COLORS.line, padding: 14 },
  rulesTitle: { color: COLORS.accent, fontWeight: '900', fontSize: 10, letterSpacing: 1.2 },
  rulesText: { color: '#CCD2DD', fontSize: 12, lineHeight: 18, marginTop: 5 },
  record: { color: COLORS.muted, textAlign: 'center', marginTop: 13, fontSize: 11 },
  scoreBoard: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 14, backgroundColor: COLORS.panel, padding: 14, borderRadius: 15, borderWidth: 1, borderColor: COLORS.line },
  scoreName: { color: COLORS.muted, fontWeight: '900', fontSize: 11 },
  score: { color: '#FFF', fontWeight: '900', fontSize: 27 },
  roundTitle: { color: '#FFF', fontWeight: '900', textAlign: 'center', marginVertical: 14 },
  battleRow: { flexDirection: 'row', alignItems: 'center', gap: 7 },
  battleCard: { flex: 1, position: 'relative' },
  battleScore: { position: 'absolute', right: 8, bottom: 8, color: '#111', backgroundColor: COLORS.accent, borderRadius: 15, minWidth: 30, paddingVertical: 5, textAlign: 'center', fontWeight: '900' },
  vs: { color: '#FFF', fontWeight: '900', fontSize: 12 },
  roundResult: { fontWeight: '900', textAlign: 'center', marginTop: 14, letterSpacing: 1 },
  readyDuel: { minHeight: 300, alignItems: 'center', justifyContent: 'center' },
  readyDuelText: { color: COLORS.muted, fontWeight: '800' },
  finalResult: { color: '#FFF', fontWeight: '900', fontSize: 26, textAlign: 'center', marginTop: 20 },
  infoBox: { backgroundColor: COLORS.panel, borderRadius: 14, borderWidth: 1, borderColor: COLORS.line, padding: 14, marginTop: 12 },
  infoTitle: { color: '#FFF', fontWeight: '900', fontSize: 13 },
  infoText: { color: COLORS.muted, marginTop: 5, fontSize: 11, lineHeight: 17 },
  debugText: { color: COLORS.muted, textAlign: 'center', marginTop: 18, fontSize: 10 },
  dangerButton: { borderWidth: 1, borderColor: '#6B2E35', backgroundColor: '#2A1619', borderRadius: 13, padding: 12, alignItems: 'center', marginTop: 12 },
  dangerButtonText: { color: '#FF7C88', fontWeight: '900', fontSize: 10 },
  nav: { minHeight: 66, flexDirection: 'row', borderTopWidth: 1, borderColor: COLORS.line, backgroundColor: '#0D1017', paddingTop: 7, paddingBottom: 5 },
  navItem: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  navIcon: { color: '#6F788B', fontSize: 17, fontWeight: '900' },
  navLabel: { color: '#6F788B', fontSize: 8, fontWeight: '800', marginTop: 3 },
  navActive: { color: COLORS.accent },
});
