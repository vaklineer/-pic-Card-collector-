import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  Animated,
  FlatList,
  Image,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider, useSafeAreaInsets } from 'react-native-safe-area-context';
import { CARDS, CARDS_BY_ID, HOLOS, RARITIES } from './data/cards';

const OLD_STORAGE_KEY = '@boostercult/state/v1';
const STORAGE_KEY = '@boostercult/state/v2';
const WIKI_CACHE_KEY = '@boostercult/wiki-cache/v2';
const PACK_PRICE = 250;
const STARTING_CREDITS = 1500;
const TABS = [
  { id: 'home', label: 'Accueil', icon: '⌂' },
  { id: 'open', label: 'Ouvrir', icon: '✦' },
  { id: 'collection', label: 'Collection', icon: '▦' },
  { id: 'play', label: 'Jouer', icon: '⚔' },
  { id: 'info', label: 'Infos', icon: 'ⓘ' },
];

const rarityOrder = ['common', 'uncommon', 'rare', 'epic', 'legendary'];
const holoOrder = ['standard', 'silver', 'prism', 'galaxy', 'aurora'];
const wikiMemory = new Map();
let wikiDiskCache = null;
let wikiDiskPromise = null;

function clamp(n, min, max) { return Math.min(max, Math.max(min, n)); }
function rand(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function uid(prefix = 'copy') { return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`; }
function chooseWeighted(entries) {
  let r = Math.random();
  for (const [key, weight] of entries) {
    r -= weight;
    if (r <= 0) return key;
  }
  return entries[entries.length - 1][0];
}
function rollHolo() {
  return chooseWeighted(holoOrder.map(key => [key, HOLOS[key].chance]));
}
function rollGrade() {
  const r = Math.random();
  if (r < 0.05) return rand(94, 100);
  if (r < 0.28) return rand(80, 93);
  if (r < 0.70) return rand(58, 79);
  if (r < 0.94) return rand(30, 57);
  return rand(8, 29);
}
function gradeLetter(grade = 50) {
  if (grade >= 95) return 'S';
  if (grade >= 82) return 'A';
  if (grade >= 64) return 'B';
  if (grade >= 40) return 'C';
  return 'D';
}
function gradeLabel(grade = 50) {
  const l = gradeLetter(grade);
  return l === 'S' ? 'Exceptionnelle' : l === 'A' ? 'Très propre' : l === 'B' ? 'Bon état' : l === 'C' ? 'Marquée' : 'Abîmée';
}
function calcPower(card, copy) {
  const rarity = RARITIES[card.rarity];
  const holo = HOLOS[copy?.holo || 'standard'];
  const grade = copy?.grade ?? 50;
  return Math.round((rarity.basePower + grade * 0.42) * holo.multiplier);
}
function calcValue(card, copy) {
  const rarityBase = { common: 12, uncommon: 25, rare: 55, epic: 120, legendary: 280 }[card.rarity];
  const condition = 0.65 + (copy?.grade ?? 50) / 160;
  return Math.round(rarityBase * condition * HOLOS[copy?.holo || 'standard'].multiplier);
}
function normalizeCopy(raw, fallbackCardId) {
  const cardId = raw?.cardId || raw?.id || fallbackCardId;
  if (!CARDS_BY_ID[cardId]) return null;
  return {
    uid: raw?.uid || uid(cardId),
    cardId,
    holo: HOLOS[raw?.holo] ? raw.holo : 'standard',
    grade: clamp(Number(raw?.grade ?? raw?.condition ?? raw?.bestGrade ?? 52), 1, 100),
    pulledAt: raw?.pulledAt || Date.now(),
  };
}
function migrateCollection(rawCollection) {
  if (!rawCollection) return [];
  if (Array.isArray(rawCollection)) {
    return rawCollection.map((v) => {
      if (typeof v === 'string') return normalizeCopy({}, v);
      return normalizeCopy(v, v?.cardId || v?.id);
    }).filter(Boolean);
  }
  if (typeof rawCollection === 'object') {
    const out = [];
    for (const [cardId, value] of Object.entries(rawCollection)) {
      if (!CARDS_BY_ID[cardId]) continue;
      if (typeof value === 'number') {
        for (let i = 0; i < value; i++) out.push(normalizeCopy({}, cardId));
      } else if (value && typeof value === 'object') {
        const count = Math.max(1, Number(value.count || value.quantity || value.qty || 1));
        for (let i = 0; i < count; i++) {
          out.push(normalizeCopy({
            ...value,
            grade: i === 0 ? (value.bestGrade ?? value.grade ?? value.score) : 52,
            holo: i === 0 ? (value.bestHolo ?? value.holo) : 'standard',
          }, cardId));
        }
      }
    }
    return out.filter(Boolean);
  }
  return [];
}
async function loadState() {
  try {
    const v2 = await AsyncStorage.getItem(STORAGE_KEY);
    if (v2) {
      const p = JSON.parse(v2);
      return {
        credits: Number(p.credits ?? STARTING_CREDITS),
        boostersOpened: Number(p.boostersOpened ?? 0),
        collection: migrateCollection(p.collection),
      };
    }
    const old = await AsyncStorage.getItem(OLD_STORAGE_KEY);
    if (old) {
      const p = JSON.parse(old);
      return {
        credits: Number(p.credits ?? p.coins ?? p.gold ?? STARTING_CREDITS),
        boostersOpened: Number(p.boostersOpened ?? p.opened ?? 0),
        collection: migrateCollection(p.collection ?? p.cards ?? p.inventory),
      };
    }
  } catch (e) {
    console.warn('State migration failed', e);
  }
  return { credits: STARTING_CREDITS, boostersOpened: 0, collection: [] };
}
async function loadWikiDiskCache() {
  if (wikiDiskCache) return wikiDiskCache;
  if (!wikiDiskPromise) {
    wikiDiskPromise = AsyncStorage.getItem(WIKI_CACHE_KEY)
      .then(v => (v ? JSON.parse(v) : {}))
      .catch(() => ({}))
      .then(v => { wikiDiskCache = v || {}; return wikiDiskCache; });
  }
  return wikiDiskPromise;
}
async function saveWikiCacheEntry(key, value) {
  const cache = await loadWikiDiskCache();
  cache[key] = value;
  wikiDiskCache = cache;
  AsyncStorage.setItem(WIKI_CACHE_KEY, JSON.stringify(cache)).catch(() => {});
}
async function fetchJson(url) {
  const response = await fetch(url, {
    headers: { 'Api-User-Agent': 'BoosterCult/0.2 (prototype; Wikimedia attribution in-app)' },
  });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}
async function resolveCommonsMedia(query) {
  const url = 'https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*' +
    '&generator=search&gsrnamespace=6&gsrlimit=6&prop=imageinfo&iiprop=url&iiurlwidth=900&gsrsearch=' + encodeURIComponent(query);
  const json = await fetchJson(url);
  const pages = Object.values(json?.query?.pages || {});
  for (const page of pages) {
    const info = page?.imageinfo?.[0];
    const uri = info?.thumburl || info?.url;
    if (uri && /\.(jpe?g|png|webp)(\?|$)/i.test(uri)) {
      return { uri, sourceUrl: page?.canonicalurl || `https://commons.wikimedia.org/wiki/${encodeURIComponent(page.title || '')}` };
    }
  }
  return null;
}
async function resolveWikiAsset(card, forceCommons = false) {
  const cacheKey = `${card.id}:${forceCommons ? 'commons' : 'wiki'}`;
  if (wikiMemory.has(cacheKey)) return wikiMemory.get(cacheKey);
  const disk = await loadWikiDiskCache();
  if (disk[cacheKey]?.uri) {
    wikiMemory.set(cacheKey, disk[cacheKey]);
    return disk[cacheKey];
  }
  let result = null;
  if (!forceCommons) {
    try {
      const url = 'https://fr.wikipedia.org/w/api.php?action=query&format=json&origin=*' +
        '&redirects=1&prop=pageimages%7Cinfo&inprop=url&piprop=thumbnail&pithumbsize=900&titles=' + encodeURIComponent(card.wikiTitle || card.name);
      const json = await fetchJson(url);
      const page = Object.values(json?.query?.pages || {})[0];
      if (page?.thumbnail?.source) result = { uri: page.thumbnail.source, sourceUrl: page.fullurl || `https://fr.wikipedia.org/wiki/${encodeURIComponent(card.wikiTitle)}` };
    } catch (_) {}
  }
  if (!result) {
    try { result = await resolveCommonsMedia(card.wikiTitle || card.name); } catch (_) {}
  }
  if (result) {
    wikiMemory.set(cacheKey, result);
    saveWikiCacheEntry(cacheKey, result);
  }
  return result;
}

function WikiImage({ card, style, onSource, dim = false }) {
  const [asset, setAsset] = useState(null);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);
  const [nonce, setNonce] = useState(0);
  useEffect(() => {
    let alive = true;
    setLoading(true); setFailed(false);
    resolveWikiAsset(card, nonce > 0).then((a) => {
      if (!alive) return;
      setAsset(a);
      if (a?.sourceUrl) onSource?.(a.sourceUrl);
      setLoading(false);
      setFailed(!a?.uri);
    });
    return () => { alive = false; };
  }, [card.id, nonce]);
  if (!asset?.uri || failed) {
    return (
      <Pressable style={[styles.imageFallback, style]} onPress={() => setNonce(v => v + 1)}>
        {loading ? <ActivityIndicator color="#DDE5F5" /> : <Text style={styles.fallbackIcon}>◈</Text>}
        <Text style={styles.imageFallbackText}>{loading ? 'Image Wikipédia…' : 'Toucher pour réessayer'}</Text>
      </Pressable>
    );
  }
  return (
    <View style={[style, { overflow: 'hidden' }]}>
      <Image
        source={{ uri: asset.uri }}
        resizeMode="cover"
        style={StyleSheet.absoluteFill}
        onError={() => { setFailed(true); setNonce(v => v + 1); }}
      />
      {dim ? <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(5,7,12,.20)' }]} /> : null}
    </View>
  );
}

function HoloOverlay({ type = 'standard', animated = false }) {
  const anim = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!animated || type === 'standard') return;
    const loop = Animated.loop(Animated.timing(anim, { toValue: 1, duration: 2400, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [animated, type]);
  if (type === 'standard') return null;
  const move = anim.interpolate({ inputRange: [0, 1], outputRange: [-220, 220] });
  if (type === 'silver') {
    return <View pointerEvents="none" style={StyleSheet.absoluteFill}><View style={styles.silverWash}/><View style={styles.silverLine}/></View>;
  }
  if (type === 'prism') {
    return (
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        <View style={[styles.prismBar, { backgroundColor: 'rgba(0,230,255,.18)', left: '-8%' }]} />
        <View style={[styles.prismBar, { backgroundColor: 'rgba(255,0,190,.16)', left: '27%' }]} />
        <View style={[styles.prismBar, { backgroundColor: 'rgba(255,230,0,.15)', left: '62%' }]} />
        {animated ? <Animated.View style={[styles.scanLine, { transform: [{ translateX: move }, { rotate: '18deg' }] }]} /> : null}
      </View>
    );
  }
  if (type === 'galaxy') {
    return (
      <View pointerEvents="none" style={StyleSheet.absoluteFill}>
        <View style={styles.galaxyWash}/>
        {['✦','·','✧','⋆','·','✦','∙','✧'].map((s,i)=><Text key={i} style={[styles.star,{left:`${8+(i*13)%82}%`,top:`${8+(i*19)%78}%`,fontSize: i%3===0?18:11}]}>{s}</Text>)}
      </View>
    );
  }
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFill}>
      <View style={styles.auroraA}/><View style={styles.auroraB}/><View style={styles.auroraC}/>
      <Text style={styles.auroraGlyph}>✦</Text>
    </View>
  );
}

function CardFace({ card, copy, width, onPress, large = false, animateHolo = false }) {
  const rarity = RARITIES[card.rarity];
  const holo = HOLOS[copy?.holo || 'standard'];
  const grade = copy?.grade ?? 52;
  const height = width * 1.42;
  return (
    <Pressable onPress={onPress} disabled={!onPress} style={({ pressed }) => [
      styles.cardShell,
      { width, height, borderColor: holo.color, transform: [{ scale: pressed ? 0.985 : 1 }] },
      large && styles.cardShellLarge,
    ]}>
      <View style={[styles.rarityHeader, { backgroundColor: rarity.color }]}>
        <Text numberOfLines={1} style={[styles.rarityText, { color: rarity.ink }]}>{rarity.label}</Text>
        <Text style={[styles.cardNumber, { color: rarity.ink }]}>#{card.id.slice(1)}</Text>
      </View>
      <View style={styles.cardNameBand}>
        <Text numberOfLines={2} style={[styles.cardName, large && styles.cardNameLarge]}>{card.name}</Text>
      </View>
      <WikiImage card={card} style={styles.cardImage} />
      <View style={styles.cardBottom}>
        <View style={styles.cardMetaRow}>
          <View style={[styles.holoPill, { borderColor: holo.color, backgroundColor: `${holo.color}22` }]}>
            <Text style={[styles.holoPillText, { color: holo.color }]}>{holo.short} · {holo.label}</Text>
          </View>
          <View style={styles.gradePill}>
            <Text style={styles.gradePillText}>{grade} {gradeLetter(grade)}</Text>
          </View>
        </View>
        {large ? <Text numberOfLines={2} style={styles.flavorText}>{card.flavor}</Text> : null}
      </View>
      <HoloOverlay type={copy?.holo || 'standard'} animated={animateHolo} />
    </Pressable>
  );
}

function ScreenHeader({ title, subtitle, credits, uniqueCount }) {
  return (
    <View style={styles.topHeader}>
      <View style={{ flex: 1 }}>
        <Text style={styles.brandSmall}>BOOSTER CULT</Text>
        <Text style={styles.screenTitle}>{title}</Text>
        {subtitle ? <Text style={styles.screenSubtitle}>{subtitle}</Text> : null}
      </View>
      <View style={styles.headerStats}>
        <View style={styles.headerChip}><Text style={styles.headerChipIcon}>◇</Text><Text style={styles.headerChipText}>{credits}</Text></View>
        <View style={styles.headerChip}><Text style={styles.headerChipText}>{uniqueCount}/100</Text></View>
      </View>
    </View>
  );
}

function HomeScreen({ credits, collection, boostersOpened, onOpen, onCollection, onCard }) {
  const uniqueIds = [...new Set(collection.map(c => c.cardId))];
  const holoCount = collection.filter(c => c.holo !== 'standard').length;
  const best = collection.slice().sort((a,b) => calcPower(CARDS_BY_ID[b.cardId], b) - calcPower(CARDS_BY_ID[a.cardId], a))[0];
  const featuredCard = best ? CARDS_BY_ID[best.cardId] : CARDS[77];
  const featuredCopy = best || { cardId: featuredCard.id, holo: 'prism', grade: 88 };
  return (
    <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
      <View style={styles.heroPanel}>
        <Text style={styles.heroEyebrow}>SÉRIE 001</Text>
        <Text style={styles.heroTitle}>LE GRAND BAZAR</Text>
        <Text style={styles.heroText}>100 cartes réelles, absurdes ou historiques. Ouvre, compare, collectionne.</Text>
        <View style={styles.heroButtons}>
          <Pressable style={styles.primaryButton} onPress={onOpen}><Text style={styles.primaryButtonText}>OUVRIR UN BOOSTER</Text></Pressable>
          <Pressable style={styles.secondaryButton} onPress={onCollection}><Text style={styles.secondaryButtonText}>VOIR LA COLLECTION</Text></Pressable>
        </View>
      </View>
      <View style={styles.statGrid}>
        <StatBox value={`${uniqueIds.length}/100`} label="cartes uniques" />
        <StatBox value={String(holoCount)} label="holos tirées" />
        <StatBox value={String(boostersOpened)} label="boosters ouverts" />
        <StatBox value={`${credits} ◇`} label="crédits" />
      </View>
      <View style={styles.sectionHeadingRow}><Text style={styles.sectionTitle}>Carte vedette</Text><Text style={styles.sectionHint}>Toucher pour agrandir</Text></View>
      <Pressable style={styles.featureCard} onPress={() => onCard(featuredCard, featuredCopy)}>
        <WikiImage card={featuredCard} style={styles.featureImage} dim />
        <View style={styles.featureShade}/>
        <View style={styles.featureContent}>
          <Text style={styles.featureKicker}>{RARITIES[featuredCard.rarity].label} · {HOLOS[featuredCopy.holo].label}</Text>
          <Text style={styles.featureTitle}>{featuredCard.name}</Text>
          <Text style={styles.featureFlavor}>{featuredCard.flavor}</Text>
          <Text style={styles.featurePower}>PUISSANCE {calcPower(featuredCard, featuredCopy)}</Text>
        </View>
      </Pressable>
    </ScrollView>
  );
}

function StatBox({ value, label }) {
  return <View style={styles.statBox}><Text style={styles.statValue}>{value}</Text><Text style={styles.statLabel}>{label}</Text></View>;
}

function OpenScreen({ credits, onOpenPack, reveal, revealIndex, setRevealIndex, onCloseReveal }) {
  if (reveal?.length) {
    const copy = reveal[revealIndex];
    const card = CARDS_BY_ID[copy.cardId];
    const done = revealIndex >= reveal.length - 1;
    return (
      <View style={styles.revealScreen}>
        <Text style={styles.revealCounter}>CARTE {revealIndex + 1} / {reveal.length}</Text>
        <CardFace card={card} copy={copy} width={290} large animateHolo />
        <View style={styles.revealStatsRow}>
          <View style={styles.revealStat}><Text style={styles.revealStatLabel}>ÉTAT</Text><Text style={styles.revealStatValue}>{copy.grade} {gradeLetter(copy.grade)}</Text></View>
          <View style={styles.revealStat}><Text style={styles.revealStatLabel}>HOLO</Text><Text style={[styles.revealStatValue,{color:HOLOS[copy.holo].color}]}>{HOLOS[copy.holo].label}</Text></View>
          <View style={styles.revealStat}><Text style={styles.revealStatLabel}>VALEUR</Text><Text style={styles.revealStatValue}>~{calcValue(card,copy)} ◇</Text></View>
        </View>
        <Pressable style={styles.primaryButtonWide} onPress={() => done ? onCloseReveal() : setRevealIndex(v => v + 1)}>
          <Text style={styles.primaryButtonText}>{done ? 'AJOUTER À LA COLLECTION' : 'CARTE SUIVANTE'}</Text>
        </Pressable>
      </View>
    );
  }
  return (
    <ScrollView contentContainerStyle={styles.openContent} showsVerticalScrollIndicator={false}>
      <View style={styles.packArt}>
        <View style={styles.packGlow}/>
        <Text style={styles.packMini}>SÉRIE 001</Text>
        <Text style={styles.packBrand}>BOOSTER{`\n`}CULT</Text>
        <View style={styles.packDiamond}><Text style={styles.packDiamondText}>◇</Text></View>
        <Text style={styles.packTitle}>LE GRAND BAZAR</Text>
        <Text style={styles.packInfo}>5 CARTES · 1 RARE OU MIEUX GARANTIE</Text>
        <View style={styles.packStripeA}/><View style={styles.packStripeB}/><View style={styles.packStripeC}/>
      </View>
      <Text style={styles.openTitle}>Ouvre le chaos.</Text>
      <Text style={styles.openText}>Chaque carte peut sortir en Standard, Argent, Prisme, Galaxie ou Aurore. L’état physique modifie aussi sa cote et sa puissance.</Text>
      <View style={styles.priceRow}><Text style={styles.priceLabel}>Prix du booster</Text><Text style={styles.priceValue}>{PACK_PRICE} ◇</Text></View>
      <Pressable style={[styles.primaryButtonWide, credits < PACK_PRICE && styles.buttonDisabled]} disabled={credits < PACK_PRICE} onPress={onOpenPack}>
        <Text style={styles.primaryButtonText}>{credits < PACK_PRICE ? 'CRÉDITS INSUFFISANTS' : `OUVRIR · ${PACK_PRICE} ◇`}</Text>
      </Pressable>
    </ScrollView>
  );
}

function CollectionScreen({ collection, onCard }) {
  const { width } = useWindowDimensions();
  const cardWidth = Math.floor((width - 42) / 2);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');
  const byCard = useMemo(() => {
    const map = new Map();
    collection.forEach(copy => {
      const arr = map.get(copy.cardId) || [];
      arr.push(copy); map.set(copy.cardId, arr);
    });
    return map;
  }, [collection]);
  const list = useMemo(() => {
    const q = search.trim().toLowerCase();
    return CARDS.filter(card => {
      const has = byCard.has(card.id);
      if (!has) return false;
      if (filter !== 'all' && card.rarity !== filter) return false;
      if (q && !`${card.name} ${card.category}`.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [byCard, filter, search]);
  return (
    <View style={styles.collectionScreen}>
      <View style={styles.searchBox}><Text style={styles.searchIcon}>⌕</Text><TextInput value={search} onChangeText={setSearch} placeholder="Rechercher une carte…" placeholderTextColor="#737D91" style={styles.searchInput}/></View>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.filterRow}>
        {[['all','Toutes'], ...rarityOrder.map(k => [k, RARITIES[k].label])].map(([key,label]) => (
          <Pressable key={key} style={[styles.filterChip, filter === key && styles.filterChipActive, filter !== 'all' && filter === key && { borderColor: RARITIES[key].color }]} onPress={() => setFilter(key)}>
            <Text style={[styles.filterChipText, filter === key && styles.filterChipTextActive]}>{label}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <FlatList
        data={list}
        keyExtractor={item => item.id}
        numColumns={2}
        keyboardShouldPersistTaps="handled"
        columnWrapperStyle={styles.gridRow}
        contentContainerStyle={styles.gridContent}
        initialNumToRender={8}
        windowSize={5}
        renderItem={({ item }) => {
          const copies = byCard.get(item.id) || [];
          const best = copies.slice().sort((a,b) => calcPower(item,b)-calcPower(item,a))[0];
          return (
            <View style={{ width: cardWidth }}>
              <CardFace card={item} copy={best} width={cardWidth} onPress={() => onCard(item,best)} />
              <View style={styles.gridMeta}><Text style={styles.copyCount}>×{copies.length}</Text><Text style={styles.bestGrade}>meilleure {best?.grade ?? 0} {gradeLetter(best?.grade)}</Text></View>
            </View>
          );
        }}
        ListEmptyComponent={<View style={styles.emptyState}><Text style={styles.emptyIcon}>◇</Text><Text style={styles.emptyTitle}>Rien ici pour l’instant</Text><Text style={styles.emptyText}>Ouvre un booster, ou change ton filtre.</Text></View>}
      />
    </View>
  );
}

function PlayScreen({ collection }) {
  const [selected, setSelected] = useState(collection[0] || null);
  const [enemy, setEnemy] = useState(null);
  const [result, setResult] = useState(null);
  useEffect(() => { if (!selected && collection[0]) setSelected(collection[0]); }, [collection.length]);
  const owned = useMemo(() => collection.slice().sort((a,b) => calcPower(CARDS_BY_ID[b.cardId],b)-calcPower(CARDS_BY_ID[a.cardId],a)).slice(0,12), [collection]);
  const fight = () => {
    if (!selected) return;
    const enemyCard = CARDS[rand(0, CARDS.length - 1)];
    const enemyCopy = { uid:uid('cpu'), cardId:enemyCard.id, holo:rollHolo(), grade:rollGrade() };
    setEnemy(enemyCopy);
    const playerPower = calcPower(CARDS_BY_ID[selected.cardId], selected) + rand(-6,6);
    const enemyPower = calcPower(enemyCard, enemyCopy) + rand(-6,6);
    setResult(playerPower === enemyPower ? 'ÉGALITÉ' : playerPower > enemyPower ? 'VICTOIRE' : 'DÉFAITE');
  };
  if (!collection.length) return <View style={styles.emptyStateFull}><Text style={styles.emptyIcon}>⚔</Text><Text style={styles.emptyTitle}>Il te faut une carte</Text><Text style={styles.emptyText}>Ouvre ton premier booster pour lancer un duel.</Text></View>;
  return (
    <ScrollView contentContainerStyle={styles.playContent} showsVerticalScrollIndicator={false}>
      <Text style={styles.sectionTitle}>Choisis ton combattant</Text>
      <Text style={styles.sectionHintLeft}>La rareté, l’état et le type de holo influencent la puissance.</Text>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.fighterRow}>
        {owned.map(copy => {
          const card = CARDS_BY_ID[copy.cardId];
          const active = selected?.uid === copy.uid;
          return <Pressable key={copy.uid} onPress={() => {setSelected(copy);setEnemy(null);setResult(null);}} style={[styles.fighterChip, active && styles.fighterChipActive]}><Text style={styles.fighterName} numberOfLines={1}>{card.name}</Text><Text style={styles.fighterPower}>{calcPower(card,copy)} P</Text></Pressable>;
        })}
      </ScrollView>
      <View style={styles.battleRow}>
        <BattleSlot label="TOI" copy={selected}/>
        <Text style={styles.vs}>VS</Text>
        <BattleSlot label="CPU" copy={enemy}/>
      </View>
      {result ? <View style={[styles.resultBanner, result === 'VICTOIRE' ? styles.resultWin : result === 'DÉFAITE' ? styles.resultLose : null]}><Text style={styles.resultText}>{result}</Text></View> : null}
      <Pressable style={styles.primaryButtonWide} onPress={fight}><Text style={styles.primaryButtonText}>{enemy ? 'REJOUER' : 'LANCER LE DUEL'}</Text></Pressable>
    </ScrollView>
  );
}

function BattleSlot({ label, copy }) {
  if (!copy) return <View style={styles.battleSlotEmpty}><Text style={styles.battleLabel}>{label}</Text><Text style={styles.battleMystery}>?</Text><Text style={styles.battleEmptyText}>adversaire mystère</Text></View>;
  const card = CARDS_BY_ID[copy.cardId];
  return <View style={styles.battleSlot}><Text style={styles.battleLabel}>{label}</Text><WikiImage card={card} style={styles.battleImage}/><Text style={styles.battleName} numberOfLines={2}>{card.name}</Text><Text style={styles.battlePower}>{calcPower(card,copy)} P</Text><Text style={[styles.battleHolo,{color:HOLOS[copy.holo].color}]}>{HOLOS[copy.holo].label} · {copy.grade}{gradeLetter(copy.grade)}</Text></View>;
}

function InfoScreen({ onClearImageCache }) {
  return (
    <ScrollView contentContainerStyle={styles.infoContent} showsVerticalScrollIndicator={false}>
      <InfoBlock title="Les holos ont enfin un vrai intérêt">
        {holoOrder.map(k => <HoloLegend key={k} type={k}/>) }
      </InfoBlock>
      <InfoBlock title="État de la carte">
        <Text style={styles.infoText}>Chaque exemplaire reçoit une note de 1 à 100. Une carte très propre vaut et frappe davantage ; une carte abîmée peut devenir une curiosité de collection. Grades : S, A, B, C, D.</Text>
      </InfoBlock>
      <InfoBlock title="Images & sources">
        <Text style={styles.infoText}>Les visuels sont récupérés à la demande depuis Wikipédia puis Wikimedia Commons. Booster Cult affiche une source ouvrable sur chaque fiche. Les licences restent celles indiquées sur la page du média.</Text>
        <Pressable style={styles.secondaryButtonWide} onPress={onClearImageCache}><Text style={styles.secondaryButtonText}>RÉPARER LE CACHE IMAGES</Text></Pressable>
      </InfoBlock>
      <InfoBlock title="Série 001 · Le Grand Bazar">
        <Text style={styles.infoText}>100 cartes. 50 communes, 25 peu communes, 15 rares, 7 épiques et 3 légendaires. Les boosters contiennent 5 cartes avec une rare ou mieux garantie.</Text>
      </InfoBlock>
    </ScrollView>
  );
}
function InfoBlock({ title, children }) { return <View style={styles.infoBlock}><Text style={styles.infoTitle}>{title}</Text>{children}</View>; }
function HoloLegend({ type }) {
  const h = HOLOS[type];
  return <View style={styles.holoLegend}><View style={[styles.holoSwatch,{backgroundColor:`${h.color}24`,borderColor:h.color}]}><Text style={[styles.holoSwatchText,{color:h.color}]}>{h.short}</Text></View><View style={{flex:1}}><Text style={styles.holoLegendName}>{h.label}</Text><Text style={styles.holoLegendDesc}>Puissance ×{h.multiplier.toFixed(2)} · chance {Math.round(h.chance*100)}%</Text></View></View>;
}

function CardDetailModal({ card, copy, onClose }) {
  const insets = useSafeAreaInsets();
  const [source, setSource] = useState(null);
  if (!card || !copy) return null;
  return (
    <Modal visible transparent animationType="fade" statusBarTranslucent navigationBarTranslucent onRequestClose={onClose}>
      <View style={[styles.modalBackdrop,{paddingTop:insets.top+18,paddingBottom:insets.bottom+18}]}>
        <Pressable style={styles.modalClose} onPress={onClose}><Text style={styles.modalCloseText}>×</Text></Pressable>
        <ScrollView contentContainerStyle={styles.modalContent} showsVerticalScrollIndicator={false}>
          <View onLayout={() => {}}>
            <CardFace card={card} copy={copy} width={300} large animateHolo />
            <WikiImage card={card} style={{width:1,height:1,position:'absolute',opacity:0}} onSource={setSource}/>
          </View>
          <View style={styles.detailGrid}>
            <DetailStat label="PUISSANCE" value={`${calcPower(card,copy)} P`}/>
            <DetailStat label="COTE" value={`~${calcValue(card,copy)} ◇`}/>
            <DetailStat label="ÉTAT" value={`${copy.grade} ${gradeLetter(copy.grade)}`}/>
            <DetailStat label="VARIANTE" value={HOLOS[copy.holo].label}/>
          </View>
          <Text style={styles.detailFlavor}>{card.flavor}</Text>
          <Text style={styles.detailSourceText}>Visuel : Wikipédia / Wikimedia Commons</Text>
          {source ? <Pressable style={styles.sourceButton} onPress={() => Linking.openURL(source)}><Text style={styles.sourceButtonText}>OUVRIR LA SOURCE ↗</Text></Pressable> : null}
        </ScrollView>
      </View>
    </Modal>
  );
}
function DetailStat({ label, value }) { return <View style={styles.detailStat}><Text style={styles.detailStatLabel}>{label}</Text><Text style={styles.detailStatValue}>{value}</Text></View>; }

function BottomTabs({ tab, onTab }) {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.bottomTabs,{paddingBottom:Math.max(insets.bottom,10), minHeight:68+Math.max(insets.bottom,10)}]}>
      {TABS.map(t => {
        const active = tab === t.id;
        return <Pressable key={t.id} onPress={() => onTab(t.id)} style={styles.tabButton}><View style={[styles.tabIconWrap,active&&styles.tabIconWrapActive]}><Text style={[styles.tabIcon,active&&styles.tabActive]}>{t.icon}</Text></View><Text style={[styles.tabLabel,active&&styles.tabActive]}>{t.label}</Text></Pressable>;
      })}
    </View>
  );
}

function AppShell() {
  const insets = useSafeAreaInsets();
  const [tab, setTab] = useState('home');
  const [state, setState] = useState({ credits: STARTING_CREDITS, boostersOpened: 0, collection: [] });
  const [ready, setReady] = useState(false);
  const [reveal, setReveal] = useState(null);
  const [revealIndex, setRevealIndex] = useState(0);
  const [detail, setDetail] = useState(null);
  useEffect(() => { loadState().then(s => { setState(s); setReady(true); }); }, []);
  useEffect(() => { if (ready) AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(state)).catch(()=>{}); }, [state, ready]);
  const uniqueCount = useMemo(() => new Set(state.collection.map(c=>c.cardId)).size, [state.collection]);
  const openPack = useCallback(() => {
    if (state.credits < PACK_PRICE) return;
    const rarities = [
      chooseWeighted([['common',.54],['uncommon',.30],['rare',.11],['epic',.04],['legendary',.01]]),
      chooseWeighted([['common',.54],['uncommon',.30],['rare',.11],['epic',.04],['legendary',.01]]),
      chooseWeighted([['common',.50],['uncommon',.32],['rare',.12],['epic',.05],['legendary',.01]]),
      chooseWeighted([['common',.46],['uncommon',.34],['rare',.14],['epic',.05],['legendary',.01]]),
      chooseWeighted([['rare',.68],['epic',.25],['legendary',.07]]),
    ];
    const used = new Set();
    const pulls = rarities.map(rarity => {
      const pool = CARDS.filter(c => c.rarity === rarity && !used.has(c.id));
      const card = pool[rand(0,pool.length-1)]; used.add(card.id);
      return { uid:uid(card.id), cardId:card.id, holo:rollHolo(), grade:rollGrade(), pulledAt:Date.now() };
    });
    setState(prev => ({ credits: prev.credits-PACK_PRICE, boostersOpened: prev.boostersOpened+1, collection:[...prev.collection,...pulls] }));
    setReveal(pulls); setRevealIndex(0);
  }, [state.credits]);
  const clearImageCache = async () => {
    wikiMemory.clear(); wikiDiskCache = {}; wikiDiskPromise = null;
    await AsyncStorage.removeItem(WIKI_CACHE_KEY);
    Alert.alert('Cache images réparé', 'Les images seront retéléchargées depuis Wikipédia au prochain affichage.');
  };
  if (!ready) return <View style={styles.loadingScreen}><ActivityIndicator size="large" color="#7FE7FF"/><Text style={styles.loadingText}>Préparation du bazar…</Text></View>;
  let title = tab === 'home' ? 'Série 001 · Le Grand Bazar' : tab === 'open' ? 'Ouvrir un booster' : tab === 'collection' ? 'Ma collection' : tab === 'play' ? 'Duel' : 'À propos';
  return (
    <View style={styles.app}>
      <StatusBar style="light" backgroundColor="#0B0D12" />
      <View style={[styles.safeTop,{paddingTop:Math.max(insets.top,Platform.OS==='android'?8:0)}]}>
        <ScreenHeader title={title} credits={state.credits} uniqueCount={uniqueCount}/>
      </View>
      <View style={[styles.content,{paddingBottom:76+Math.max(insets.bottom,10)}]}>
        {tab === 'home' && <HomeScreen credits={state.credits} collection={state.collection} boostersOpened={state.boostersOpened} onOpen={()=>setTab('open')} onCollection={()=>setTab('collection')} onCard={(card,copy)=>setDetail({card,copy})}/>} 
        {tab === 'open' && <OpenScreen credits={state.credits} onOpenPack={openPack} reveal={reveal} revealIndex={revealIndex} setRevealIndex={setRevealIndex} onCloseReveal={()=>{setReveal(null);setRevealIndex(0);setTab('collection');}}/>}
        {tab === 'collection' && <CollectionScreen collection={state.collection} onCard={(card,copy)=>setDetail({card,copy})}/>} 
        {tab === 'play' && <PlayScreen collection={state.collection}/>} 
        {tab === 'info' && <InfoScreen onClearImageCache={clearImageCache}/>} 
      </View>
      <BottomTabs tab={tab} onTab={(id)=>{setTab(id); if(id!=='open'){setReveal(null);setRevealIndex(0);}}}/>
      <CardDetailModal card={detail?.card} copy={detail?.copy} onClose={()=>setDetail(null)}/>
    </View>
  );
}

export default function App() { return <SafeAreaProvider><AppShell/></SafeAreaProvider>; }

const styles = StyleSheet.create({
  app:{flex:1,backgroundColor:'#0B0D12'},
  safeTop:{backgroundColor:'#0B0D12',zIndex:5},
  content:{flex:1},
  loadingScreen:{flex:1,backgroundColor:'#0B0D12',alignItems:'center',justifyContent:'center',gap:14},
  loadingText:{color:'#AAB2C0',fontWeight:'700'},
  topHeader:{minHeight:94,paddingHorizontal:20,paddingTop:10,paddingBottom:14,flexDirection:'row',alignItems:'center',borderBottomWidth:1,borderBottomColor:'#222A39'},
  brandSmall:{fontSize:11,fontWeight:'900',letterSpacing:2.4,color:'#7FE7FF',marginBottom:3},
  screenTitle:{fontSize:24,fontWeight:'900',color:'#F7F4EC',letterSpacing:.2},
  screenSubtitle:{fontSize:12,color:'#8D96A8',marginTop:4},
  headerStats:{flexDirection:'row',gap:8,marginLeft:12},
  headerChip:{height:42,minWidth:68,paddingHorizontal:12,borderRadius:14,borderWidth:1,borderColor:'#2B3447',backgroundColor:'#151A25',alignItems:'center',justifyContent:'center',flexDirection:'row',gap:6},
  headerChipIcon:{color:'#7FE7FF',fontSize:16,fontWeight:'900'},
  headerChipText:{color:'#F7F4EC',fontSize:15,fontWeight:'900'},
  bottomTabs:{position:'absolute',left:0,right:0,bottom:0,backgroundColor:'#0E1118F5',borderTopWidth:1,borderTopColor:'#283044',paddingTop:8,paddingHorizontal:6,flexDirection:'row',alignItems:'flex-start'},
  tabButton:{flex:1,alignItems:'center',justifyContent:'center',minHeight:52},
  tabIconWrap:{width:34,height:27,borderRadius:12,alignItems:'center',justifyContent:'center'},
  tabIconWrapActive:{backgroundColor:'#7FE7FF18'},
  tabIcon:{fontSize:20,color:'#6F788B',fontWeight:'900'},
  tabLabel:{fontSize:10,color:'#6F788B',fontWeight:'800',marginTop:2},
  tabActive:{color:'#7FE7FF'},

  scrollContent:{padding:18,paddingBottom:30,gap:18},
  heroPanel:{borderRadius:28,padding:22,backgroundColor:'#121722',borderWidth:1,borderColor:'#293247',overflow:'hidden'},
  heroEyebrow:{color:'#F7B843',fontSize:12,fontWeight:'900',letterSpacing:2.2},
  heroTitle:{color:'#F7F4EC',fontSize:34,lineHeight:38,fontWeight:'1000',letterSpacing:.2,marginTop:4},
  heroText:{color:'#AAB2C0',fontSize:14,lineHeight:21,marginTop:10,maxWidth:310},
  heroButtons:{marginTop:18,gap:10},
  primaryButton:{minHeight:50,borderRadius:16,backgroundColor:'#F7F4EC',alignItems:'center',justifyContent:'center',paddingHorizontal:18},
  primaryButtonWide:{minHeight:56,borderRadius:18,backgroundColor:'#F7F4EC',alignItems:'center',justifyContent:'center',paddingHorizontal:20,width:'100%'},
  primaryButtonText:{color:'#0B0D12',fontSize:13,fontWeight:'1000',letterSpacing:1},
  secondaryButton:{minHeight:48,borderRadius:16,borderWidth:1,borderColor:'#35405A',backgroundColor:'#161C28',alignItems:'center',justifyContent:'center',paddingHorizontal:18},
  secondaryButtonWide:{minHeight:48,borderRadius:14,borderWidth:1,borderColor:'#35405A',backgroundColor:'#161C28',alignItems:'center',justifyContent:'center',paddingHorizontal:18,marginTop:14},
  secondaryButtonText:{color:'#DCE2EE',fontSize:12,fontWeight:'900',letterSpacing:.8},
  buttonDisabled:{opacity:.38},
  statGrid:{flexDirection:'row',flexWrap:'wrap',gap:10},
  statBox:{width:'48.5%',backgroundColor:'#111620',borderWidth:1,borderColor:'#252E3F',borderRadius:18,padding:16},
  statValue:{color:'#F7F4EC',fontSize:23,fontWeight:'1000'},
  statLabel:{color:'#7F899C',fontSize:11,fontWeight:'700',marginTop:4},
  sectionHeadingRow:{flexDirection:'row',justifyContent:'space-between',alignItems:'flex-end',marginTop:2},
  sectionTitle:{color:'#F7F4EC',fontSize:20,fontWeight:'1000'},
  sectionHint:{color:'#6F788B',fontSize:11,fontWeight:'700'},
  sectionHintLeft:{color:'#7F899C',fontSize:12,lineHeight:18,marginTop:5},
  featureCard:{height:250,borderRadius:24,overflow:'hidden',backgroundColor:'#171D28',borderWidth:1,borderColor:'#343F56'},
  featureImage:{...StyleSheet.absoluteFillObject},
  featureShade:{...StyleSheet.absoluteFillObject,backgroundColor:'rgba(6,8,13,.48)'},
  featureContent:{flex:1,justifyContent:'flex-end',padding:20},
  featureKicker:{color:'#7FE7FF',fontSize:11,fontWeight:'900',letterSpacing:1.3},
  featureTitle:{color:'#FFF',fontSize:28,fontWeight:'1000',marginTop:4},
  featureFlavor:{color:'#D5DBE7',fontSize:13,marginTop:6,maxWidth:290},
  featurePower:{color:'#F7B843',fontSize:12,fontWeight:'1000',marginTop:12},

  cardShell:{backgroundColor:'#F4F0E5',borderRadius:19,borderWidth:2,overflow:'hidden',shadowColor:'#000',shadowOpacity:.36,shadowRadius:10,shadowOffset:{width:0,height:6},elevation:8},
  cardShellLarge:{borderRadius:24,borderWidth:3},
  rarityHeader:{height:'11%',minHeight:26,paddingHorizontal:10,flexDirection:'row',alignItems:'center',justifyContent:'space-between'},
  rarityText:{fontSize:11,fontWeight:'1000',letterSpacing:.8,maxWidth:'70%'},
  cardNumber:{fontSize:11,fontWeight:'900'},
  cardNameBand:{height:'15%',minHeight:34,backgroundColor:'#F7F1E4',paddingHorizontal:10,justifyContent:'center',borderBottomWidth:1,borderBottomColor:'#B9B6AD'},
  cardName:{fontSize:16,lineHeight:18,fontWeight:'1000',color:'#111319'},
  cardNameLarge:{fontSize:22,lineHeight:24},
  cardImage:{height:'50%',backgroundColor:'#CBD0D7'},
  cardBottom:{flex:1,backgroundColor:'#E9E3D5',paddingHorizontal:8,paddingTop:7,paddingBottom:8,justifyContent:'space-between'},
  cardMetaRow:{flexDirection:'row',gap:5,alignItems:'center',justifyContent:'space-between'},
  holoPill:{flex:1,minHeight:24,borderWidth:1,borderRadius:8,paddingHorizontal:6,alignItems:'center',justifyContent:'center'},
  holoPillText:{fontSize:8,fontWeight:'1000',letterSpacing:.2},
  gradePill:{minWidth:38,minHeight:24,borderRadius:8,backgroundColor:'#181C25',alignItems:'center',justifyContent:'center',paddingHorizontal:5},
  gradePillText:{fontSize:8,fontWeight:'1000',color:'#F7F4EC'},
  flavorText:{fontSize:10,lineHeight:13,color:'#34363D',fontWeight:'600',marginTop:5},
  imageFallback:{backgroundColor:'#BFC3CA',alignItems:'center',justifyContent:'center',padding:8},
  fallbackIcon:{fontSize:28,color:'#687080',fontWeight:'900'},
  imageFallbackText:{marginTop:4,fontSize:9,color:'#58606E',fontWeight:'800',textAlign:'center'},

  silverWash:{...StyleSheet.absoluteFillObject,backgroundColor:'rgba(230,240,255,.12)'},
  silverLine:{position:'absolute',width:'170%',height:18,backgroundColor:'rgba(255,255,255,.20)',transform:[{rotate:'-28deg'}],top:'42%',left:'-30%'},
  prismBar:{position:'absolute',top:'-20%',bottom:'-20%',width:'30%',transform:[{rotate:'16deg'}]},
  scanLine:{position:'absolute',top:'-10%',bottom:'-10%',width:36,backgroundColor:'rgba(255,255,255,.24)'},
  galaxyWash:{...StyleSheet.absoluteFillObject,backgroundColor:'rgba(83,37,150,.11)'},
  star:{position:'absolute',color:'rgba(255,255,255,.70)',fontWeight:'1000',textShadowColor:'#7FE7FF',textShadowRadius:5},
  auroraA:{position:'absolute',left:'-20%',top:'0%',width:'70%',height:'120%',backgroundColor:'rgba(80,255,190,.13)',transform:[{rotate:'18deg'}]},
  auroraB:{position:'absolute',left:'24%',top:'-10%',width:'60%',height:'130%',backgroundColor:'rgba(90,170,255,.12)',transform:[{rotate:'-12deg'}]},
  auroraC:{position:'absolute',right:'-22%',top:'0%',width:'58%',height:'120%',backgroundColor:'rgba(255,130,230,.11)',transform:[{rotate:'20deg'}]},
  auroraGlyph:{position:'absolute',right:10,top:8,color:'rgba(255,255,255,.85)',fontSize:24,textShadowColor:'#69D58C',textShadowRadius:10},

  openContent:{padding:20,paddingTop:10,paddingBottom:30,alignItems:'center'},
  packArt:{width:280,height:390,borderRadius:28,overflow:'hidden',backgroundColor:'#171C29',borderWidth:2,borderColor:'#3E4964',alignItems:'center',justifyContent:'center',shadowColor:'#7FE7FF',shadowOpacity:.18,shadowRadius:24,elevation:8},
  packGlow:{position:'absolute',width:260,height:260,borderRadius:130,backgroundColor:'#7FE7FF14',top:40},
  packMini:{color:'#F7B843',fontSize:11,fontWeight:'1000',letterSpacing:2.4,marginBottom:12},
  packBrand:{color:'#F7F4EC',fontSize:46,lineHeight:42,fontWeight:'1000',letterSpacing:-1,textAlign:'center'},
  packDiamond:{width:66,height:66,borderRadius:20,borderWidth:2,borderColor:'#7FE7FF',alignItems:'center',justifyContent:'center',marginTop:22,transform:[{rotate:'45deg'}]},
  packDiamondText:{fontSize:30,color:'#7FE7FF',fontWeight:'1000',transform:[{rotate:'-45deg'}]},
  packTitle:{color:'#DCE2EE',fontSize:16,fontWeight:'1000',letterSpacing:1.5,marginTop:26},
  packInfo:{color:'#7F899C',fontSize:9,fontWeight:'900',letterSpacing:.8,marginTop:7},
  packStripeA:{position:'absolute',height:14,width:'150%',backgroundColor:'#438CFF33',top:72,left:-40,transform:[{rotate:'-13deg'}]},
  packStripeB:{position:'absolute',height:12,width:'150%',backgroundColor:'#A86BFF2D',bottom:78,left:-30,transform:[{rotate:'12deg'}]},
  packStripeC:{position:'absolute',height:8,width:'150%',backgroundColor:'#F7B8432E',bottom:55,left:-30,transform:[{rotate:'-8deg'}]},
  openTitle:{color:'#F7F4EC',fontSize:26,fontWeight:'1000',marginTop:24},
  openText:{color:'#8F98AA',fontSize:13,lineHeight:20,textAlign:'center',maxWidth:340,marginTop:8},
  priceRow:{width:'100%',marginTop:20,marginBottom:12,flexDirection:'row',justifyContent:'space-between',paddingHorizontal:4},
  priceLabel:{color:'#8D96A8',fontSize:13,fontWeight:'700'},
  priceValue:{color:'#F7F4EC',fontSize:16,fontWeight:'1000'},

  revealScreen:{flex:1,alignItems:'center',justifyContent:'center',padding:16,gap:14},
  revealCounter:{color:'#7F899C',fontSize:11,fontWeight:'1000',letterSpacing:2},
  revealStatsRow:{width:'100%',flexDirection:'row',gap:8},
  revealStat:{flex:1,backgroundColor:'#121722',borderWidth:1,borderColor:'#283147',borderRadius:14,paddingVertical:10,paddingHorizontal:8,alignItems:'center'},
  revealStatLabel:{color:'#697286',fontSize:8,fontWeight:'900',letterSpacing:1},
  revealStatValue:{color:'#F7F4EC',fontSize:11,fontWeight:'1000',marginTop:3,textAlign:'center'},

  collectionScreen:{flex:1,paddingTop:8},
  searchBox:{height:52,marginHorizontal:16,borderRadius:17,backgroundColor:'#131823',borderWidth:1,borderColor:'#2B3448',flexDirection:'row',alignItems:'center',paddingHorizontal:14},
  searchIcon:{fontSize:20,color:'#7F899C',marginRight:8},
  searchInput:{flex:1,color:'#F7F4EC',fontSize:15,fontWeight:'700',paddingVertical:0},
  filterRow:{paddingHorizontal:16,paddingVertical:12,gap:8},
  filterChip:{height:38,borderRadius:14,borderWidth:1,borderColor:'#303A4F',backgroundColor:'#111620',paddingHorizontal:16,alignItems:'center',justifyContent:'center'},
  filterChipActive:{backgroundColor:'#F7F4EC',borderColor:'#F7F4EC'},
  filterChipText:{color:'#929BAD',fontSize:10,fontWeight:'900',letterSpacing:.3},
  filterChipTextActive:{color:'#0D1016'},
  gridContent:{paddingHorizontal:14,paddingBottom:24},
  gridRow:{justifyContent:'space-between',marginBottom:16},
  gridMeta:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',paddingHorizontal:3,marginTop:6},
  copyCount:{color:'#F7F4EC',fontSize:11,fontWeight:'1000'},
  bestGrade:{color:'#7F899C',fontSize:9,fontWeight:'800'},
  emptyState:{alignItems:'center',justifyContent:'center',paddingVertical:70,paddingHorizontal:24},
  emptyStateFull:{flex:1,alignItems:'center',justifyContent:'center',padding:30},
  emptyIcon:{fontSize:42,color:'#48536A'},
  emptyTitle:{color:'#F7F4EC',fontSize:18,fontWeight:'1000',marginTop:12},
  emptyText:{color:'#7F899C',fontSize:12,textAlign:'center',marginTop:6,lineHeight:18},

  playContent:{padding:18,paddingBottom:30},
  fighterRow:{gap:8,paddingVertical:14},
  fighterChip:{width:130,borderRadius:14,borderWidth:1,borderColor:'#2D364B',backgroundColor:'#121722',padding:10},
  fighterChipActive:{borderColor:'#7FE7FF',backgroundColor:'#162230'},
  fighterName:{color:'#DCE2EE',fontSize:11,fontWeight:'900'},
  fighterPower:{color:'#F7B843',fontSize:10,fontWeight:'1000',marginTop:5},
  battleRow:{flexDirection:'row',alignItems:'center',gap:9,marginTop:10,marginBottom:14},
  battleSlot:{flex:1,minHeight:270,borderRadius:20,borderWidth:1,borderColor:'#303A50',backgroundColor:'#111620',padding:10,alignItems:'center'},
  battleSlotEmpty:{flex:1,minHeight:270,borderRadius:20,borderWidth:1,borderStyle:'dashed',borderColor:'#303A50',backgroundColor:'#0F131C',padding:10,alignItems:'center',justifyContent:'center'},
  battleLabel:{color:'#7FE7FF',fontSize:9,fontWeight:'1000',letterSpacing:1.3,alignSelf:'flex-start'},
  battleImage:{width:'100%',height:150,borderRadius:14,marginTop:8,backgroundColor:'#BFC3CA'},
  battleName:{color:'#F7F4EC',fontSize:14,fontWeight:'1000',textAlign:'center',marginTop:8,minHeight:34},
  battlePower:{color:'#F7B843',fontSize:17,fontWeight:'1000',marginTop:2},
  battleHolo:{fontSize:8,fontWeight:'900',marginTop:3},
  battleMystery:{fontSize:56,color:'#343E54',fontWeight:'1000'},
  battleEmptyText:{color:'#5F687B',fontSize:10,fontWeight:'700'},
  vs:{color:'#596276',fontSize:13,fontWeight:'1000'},
  resultBanner:{borderRadius:16,padding:12,alignItems:'center',marginBottom:12,backgroundColor:'#222838',borderWidth:1,borderColor:'#3C465D'},
  resultWin:{backgroundColor:'#173525',borderColor:'#3A8C5E'},
  resultLose:{backgroundColor:'#371C24',borderColor:'#9C465A'},
  resultText:{color:'#F7F4EC',fontSize:16,fontWeight:'1000',letterSpacing:1.5},

  infoContent:{padding:18,paddingBottom:30,gap:14},
  infoBlock:{backgroundColor:'#111620',borderRadius:20,borderWidth:1,borderColor:'#283147',padding:16},
  infoTitle:{color:'#F7F4EC',fontSize:17,fontWeight:'1000',marginBottom:10},
  infoText:{color:'#929BAD',fontSize:12,lineHeight:19},
  holoLegend:{flexDirection:'row',alignItems:'center',gap:10,paddingVertical:8,borderBottomWidth:1,borderBottomColor:'#20283A'},
  holoSwatch:{width:52,height:38,borderRadius:11,borderWidth:1,alignItems:'center',justifyContent:'center'},
  holoSwatchText:{fontSize:12,fontWeight:'1000'},
  holoLegendName:{color:'#E5E9F1',fontSize:12,fontWeight:'1000'},
  holoLegendDesc:{color:'#747E92',fontSize:9,fontWeight:'700',marginTop:2},

  modalBackdrop:{flex:1,backgroundColor:'rgba(4,6,10,.94)',alignItems:'center'},
  modalClose:{position:'absolute',right:18,top:18,width:42,height:42,borderRadius:21,backgroundColor:'#1A202C',borderWidth:1,borderColor:'#354059',zIndex:10,alignItems:'center',justifyContent:'center'},
  modalCloseText:{color:'#F7F4EC',fontSize:28,lineHeight:30,fontWeight:'500'},
  modalContent:{alignItems:'center',paddingHorizontal:20,paddingTop:26,paddingBottom:30},
  detailGrid:{width:300,flexDirection:'row',flexWrap:'wrap',gap:8,marginTop:16},
  detailStat:{width:146,backgroundColor:'#111620',borderWidth:1,borderColor:'#283147',borderRadius:13,padding:10},
  detailStatLabel:{color:'#687287',fontSize:8,fontWeight:'1000',letterSpacing:1},
  detailStatValue:{color:'#F7F4EC',fontSize:12,fontWeight:'1000',marginTop:3},
  detailFlavor:{width:300,color:'#B4BCCB',fontSize:13,lineHeight:20,textAlign:'center',marginTop:16},
  detailSourceText:{color:'#687287',fontSize:9,marginTop:14},
  sourceButton:{marginTop:8,borderRadius:12,borderWidth:1,borderColor:'#33405A',paddingVertical:10,paddingHorizontal:14},
  sourceButtonText:{color:'#7FE7FF',fontSize:10,fontWeight:'1000',letterSpacing:.7},
});
