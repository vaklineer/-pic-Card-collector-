
export const COLORS = {
  bg: '#0B0D12',
  panel: '#141821',
  panel2: '#1B2130',
  text: '#F7F4EC',
  muted: '#9EA7B8',
  line: '#2B3345',
  accent: '#F5B942',
  common: '#A9AFBA',
  uncommon: '#48B96B',
  rare: '#3F8CFF',
  epic: '#A15CFF',
  legendary: '#F4B63D',
  cursed: '#E0424F',
};

export const RARITIES = {
  common: { label: 'COMMUNE', color: COLORS.common, weight: 58, multiplier: 1 },
  uncommon: { label: 'PEU COMMUNE', color: COLORS.uncommon, weight: 24, multiplier: 1.35 },
  rare: { label: 'RARE', color: COLORS.rare, weight: 11, multiplier: 1.9 },
  epic: { label: 'ÉPIQUE', color: COLORS.epic, weight: 5, multiplier: 2.8 },
  legendary: { label: 'LÉGENDAIRE', color: COLORS.legendary, weight: 1.6, multiplier: 5 },
  cursed: { label: 'MAUDITE', color: COLORS.cursed, weight: 0.4, multiplier: 9 },
};

export const VARIANTS = {
  standard: { label: 'Standard', weight: 78, multiplier: 1 },
  holo: { label: 'Holo', weight: 12, multiplier: 1.55 },
  fullArt: { label: 'Full Art', weight: 5.5, multiplier: 2.2 },
  gold: { label: 'Gold', weight: 2.5, multiplier: 3.5 },
  glitch: { label: 'Glitch', weight: 1.5, multiplier: 5 },
  numbered: { label: 'Numérotée', weight: 0.5, multiplier: 8 },
};

export const CONDITIONS = {
  mint: { label: 'Impeccable', short: 'MINT', weight: 5, multiplier: 1.35, damage: 0 },
  nearMint: { label: 'Quasi neuve', short: 'NM', weight: 18, multiplier: 1.16, damage: 0.05 },
  excellent: { label: 'Bien conservée', short: 'EX', weight: 60, multiplier: 1, damage: 0.12 },
  played: { label: 'Usée', short: 'PL', weight: 10, multiplier: 0.82, damage: 0.28 },
  damaged: { label: 'Abîmée', short: 'DMG', weight: 5, multiplier: 0.62, damage: 0.52 },
  wrecked: { label: 'Massacrée', short: 'WRK', weight: 2, multiplier: 0.38, damage: 0.8 },
};

export const VARIANT_ORDER = ['standard','holo','fullArt','gold','glitch','numbered'];
export const CONDITION_ORDER = ['mint','nearMint','excellent','played','damaged','wrecked'];
