
import React, { useEffect, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  Linking,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { CONDITIONS, COLORS, RARITIES, VARIANTS } from '../theme';
import { resolveWikipediaCard, resolveCommonsCredit } from '../services/wiki';

const variantAccent = (variant, rarityColor) => {
  if (variant === 'gold' || variant === 'numbered') return '#F6C453';
  if (variant === 'glitch') return '#FF3D7F';
  if (variant === 'holo') return '#7FE7FF';
  return rarityColor;
};

export function CardFront({ card, instance, compact = false, onPress }) {
  const [wiki, setWiki] = useState(null);
  const rarity = RARITIES[card.rarity];
  const variant = VARIANTS[instance?.variant || 'standard'];
  const condition = CONDITIONS[instance?.condition || 'excellent'];
  const accent = variantAccent(instance?.variant, rarity.color);

  useEffect(() => {
    let alive = true;
    resolveWikipediaCard(card).then((result) => alive && setWiki(result)).catch(() => {});
    return () => { alive = false; };
  }, [card.id]);

  const imageHeight = compact ? 128 : 260;
  const frameStyle = {
    borderColor: accent,
    shadowColor: accent,
    shadowOpacity: instance?.variant === 'holo' || instance?.variant === 'gold' ? 0.55 : 0.18,
  };

  return (
    <Pressable disabled={!onPress} onPress={onPress} style={[styles.card, compact && styles.cardCompact, frameStyle]}>
      <View style={[styles.rarityBar, { backgroundColor: rarity.color }]}>
        <Text style={styles.rarityText}>{rarity.label}</Text>
        <Text style={styles.cardNo}>#{String(card.number).padStart(3,'0')}</Text>
      </View>

      <View style={styles.titleWrap}>
        <Text numberOfLines={1} style={[styles.title, compact && styles.titleCompact]}>{card.name}</Text>
        {!compact && <Text style={styles.category}>{card.category} · {variant.label}</Text>}
      </View>

      <View style={[styles.imageWrap, { height: imageHeight }]}>
        {wiki?.imageUrl ? (
          <Image source={{ uri: wiki.imageUrl }} style={styles.image} resizeMode="cover" />
        ) : (
          <View style={styles.imageFallback}>
            <ActivityIndicator color={accent} />
            <Text style={styles.imageFallbackText}>Wikipédia</Text>
          </View>
        )}

        {instance?.variant === 'holo' && <View pointerEvents="none" style={styles.holoOverlay} />}
        {instance?.variant === 'glitch' && (
          <>
            <View pointerEvents="none" style={[styles.glitchBar, { top: '28%' }]} />
            <View pointerEvents="none" style={[styles.glitchBar, styles.glitchBar2, { top: '63%' }]} />
          </>
        )}
        {instance?.variant === 'numbered' && instance.serial && (
          <View style={styles.serial}>
            <Text style={styles.serialText}>{instance.serial}</Text>
          </View>
        )}
      </View>

      {!compact && (
        <>
          <Text style={styles.flavor}>{card.flavor}</Text>
          <View style={styles.stats}>
            <Stat label="AURA" icon="✦" value={card.aura} />
            <Stat label="CHAOS" icon="◉" value={card.chaos} />
            <Stat label="CULOT" icon="◆" value={card.culot} />
          </View>
          <View style={styles.footerRow}>
            <Text style={styles.condition}>{condition.short} · {condition.label}</Text>
            <Text style={[styles.value, { color: accent }]}>{instance?.value ?? card.baseValue} C</Text>
          </View>
          <Text style={styles.source}>Visuel : Wikipédia / Wikimedia Commons</Text>
        </>
      )}
    </Pressable>
  );
}

function Stat({ label, icon, value }) {
  return (
    <View style={styles.stat}>
      <Text style={styles.statIcon}>{icon}</Text>
      <View>
        <Text style={styles.statLabel}>{label}</Text>
        <Text style={styles.statValue}>{value}</Text>
      </View>
    </View>
  );
}

export function CardBack({ card, instance }) {
  const rarity = RARITIES[card.rarity];
  const condition = CONDITIONS[instance.condition];
  const damage = condition.damage;
  const marks = useMemo(() => {
    const count = Math.round(damage * 10);
    return Array.from({ length: count }, (_, i) => ({
      key: i,
      top: `${8 + ((i * 19) % 82)}%`,
      left: `${5 + ((i * 31) % 84)}%`,
      rotate: `${-25 + ((i * 13) % 55)}deg`,
      width: 28 + ((i * 17) % 80),
    }));
  }, [damage]);

  return (
    <View style={[styles.back, { borderColor: rarity.color }]}>
      <View style={styles.backInner}>
        <Text style={styles.backBrand}>BOOSTER CULT</Text>
        <View style={[styles.backOrb, { borderColor: rarity.color }]}>
          <Text style={[styles.backQuestion, { color: rarity.color }]}>?</Text>
        </View>
        <Text style={styles.backSeries}>SÉRIE 001 · LE GRAND BAZAR</Text>
        <View style={styles.gradeBox}>
          <Text style={styles.gradeSmall}>ÉTAT</Text>
          <Text style={styles.gradeBig}>{condition.label}</Text>
          <Text style={styles.gradeMult}>Cote × {condition.multiplier.toFixed(2)}</Text>
        </View>
      </View>
      {marks.map((m) => (
        <View
          key={m.key}
          pointerEvents="none"
          style={[
            styles.wearMark,
            {
              top: m.top,
              left: m.left,
              width: m.width,
              opacity: 0.18 + damage * 0.5,
              transform: [{ rotate: m.rotate }],
            },
          ]}
        />
      ))}
      {damage > 0.45 && <View style={styles.damagedCorner} />}
      {damage > 0.7 && <View style={styles.damagedCorner2} />}
    </View>
  );
}

export function CardDetails({ card, instance, onClose }) {
  const [showBack, setShowBack] = useState(false);
  const [wiki, setWiki] = useState(null);
  const [credit, setCredit] = useState(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const w = await resolveWikipediaCard(card);
        if (!alive) return;
        setWiki(w);
        const c = await resolveCommonsCredit(w.imageFile);
        if (alive) setCredit(c);
      } catch {}
    })();
    return () => { alive = false; };
  }, [card.id]);

  return (
    <View style={styles.details}>
      <View style={styles.detailsTop}>
        <Pressable onPress={onClose} style={styles.smallButton}><Text style={styles.smallButtonText}>Fermer</Text></Pressable>
        <Pressable onPress={() => setShowBack((v) => !v)} style={styles.smallButtonAccent}>
          <Text style={styles.smallButtonText}>{showBack ? 'Voir recto' : 'Retourner'}</Text>
        </Pressable>
      </View>

      {showBack ? <CardBack card={card} instance={instance} /> : <CardFront card={card} instance={instance} />}

      <View style={styles.creditBox}>
        <Text style={styles.creditTitle}>Source du visuel</Text>
        <Text style={styles.creditText}>
          {credit ? `${credit.artist} · ${credit.license}` : 'Wikipédia / Wikimedia Commons — crédits détaillés en cours de chargement.'}
        </Text>
        <View style={styles.linkRow}>
          {wiki?.articleUrl && (
            <Pressable onPress={() => Linking.openURL(wiki.articleUrl)}>
              <Text style={styles.link}>Article Wikipédia</Text>
            </Pressable>
          )}
          {credit?.fileUrl && (
            <Pressable onPress={() => Linking.openURL(credit.fileUrl)}>
              <Text style={styles.link}>Fichier Commons</Text>
            </Pressable>
          )}
          {credit?.licenseUrl && (
            <Pressable onPress={() => Linking.openURL(credit.licenseUrl)}>
              <Text style={styles.link}>Licence</Text>
            </Pressable>
          )}
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#EEE9DD',
    borderWidth: 3,
    borderRadius: 18,
    overflow: 'hidden',
    shadowRadius: 15,
    elevation: 7,
  },
  cardCompact: { borderRadius: 13, borderWidth: 2 },
  rarityBar: { paddingHorizontal: 12, height: 28, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  rarityText: { color: '#080A0E', fontWeight: '900', fontSize: 11, letterSpacing: 0.8 },
  cardNo: { color: '#080A0E', fontWeight: '800', fontSize: 10 },
  titleWrap: { paddingHorizontal: 12, paddingTop: 8, paddingBottom: 7, backgroundColor: '#F5F0E4' },
  title: { color: '#121318', fontSize: 22, fontWeight: '900' },
  titleCompact: { fontSize: 15, paddingVertical: 1 },
  category: { color: '#565B63', fontSize: 11, marginTop: 2, fontWeight: '700' },
  imageWrap: { position: 'relative', backgroundColor: '#BFC3CA', borderTopWidth: 1, borderBottomWidth: 1, borderColor: '#4B4F57' },
  image: { width: '100%', height: '100%' },
  imageFallback: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 8 },
  imageFallbackText: { color: '#555', fontSize: 12, fontWeight: '800' },
  holoOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(130,235,255,0.13)', borderTopWidth: 2, borderBottomWidth: 2, borderColor: 'rgba(255,255,255,0.35)' },
  glitchBar: { position: 'absolute', left: -8, right: 12, height: 7, backgroundColor: 'rgba(255,0,95,0.55)' },
  glitchBar2: { left: 15, right: -12, backgroundColor: 'rgba(0,220,255,0.48)' },
  serial: { position: 'absolute', right: 8, bottom: 8, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 6, backgroundColor: '#111', borderWidth: 1, borderColor: '#E9C75B' },
  serialText: { color: '#F5D66D', fontWeight: '900', fontSize: 11 },
  flavor: { minHeight: 54, textAlign: 'center', fontStyle: 'italic', color: '#25272D', paddingHorizontal: 12, paddingVertical: 10, fontSize: 13 },
  stats: { flexDirection: 'row', borderTopWidth: 1, borderBottomWidth: 1, borderColor: '#8A877E', backgroundColor: '#151820' },
  stat: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 9, borderRightWidth: 1, borderColor: '#414650' },
  statIcon: { color: '#F0C84A', fontSize: 16 },
  statLabel: { color: '#AAB2C0', fontSize: 8, fontWeight: '800' },
  statValue: { color: '#FFF', fontSize: 18, lineHeight: 20, fontWeight: '900' },
  footerRow: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 10, paddingTop: 7, backgroundColor: '#E8E1D3' },
  condition: { color: '#4A4D55', fontSize: 10, fontWeight: '800' },
  value: { fontSize: 11, fontWeight: '900' },
  source: { textAlign: 'center', color: '#6B6D73', backgroundColor: '#E8E1D3', paddingBottom: 7, paddingTop: 3, fontSize: 8 },
  back: { aspectRatio: 0.69, backgroundColor: '#0C1018', borderWidth: 4, borderRadius: 20, overflow: 'hidden', position: 'relative' },
  backInner: { flex: 1, margin: 10, borderWidth: 1, borderColor: '#495267', borderRadius: 13, alignItems: 'center', justifyContent: 'space-around', paddingVertical: 24, backgroundColor: '#121827' },
  backBrand: { color: '#F2EAD8', fontWeight: '900', letterSpacing: 2.5, fontSize: 22 },
  backOrb: { width: 126, height: 126, borderRadius: 63, borderWidth: 6, alignItems: 'center', justifyContent: 'center', backgroundColor: '#0A0D13' },
  backQuestion: { fontSize: 72, fontWeight: '900' },
  backSeries: { color: '#8D97AA', fontSize: 10, fontWeight: '800', letterSpacing: 1 },
  gradeBox: { minWidth: '75%', borderWidth: 1, borderColor: '#495267', borderRadius: 12, padding: 12, alignItems: 'center', backgroundColor: '#0E121B' },
  gradeSmall: { color: '#7F899D', fontSize: 9, fontWeight: '900', letterSpacing: 1.5 },
  gradeBig: { color: '#FFF', fontSize: 19, fontWeight: '900', marginTop: 3 },
  gradeMult: { color: '#F5B942', fontSize: 12, fontWeight: '800', marginTop: 4 },
  wearMark: { position: 'absolute', height: 3, backgroundColor: '#E9E0CF', borderRadius: 2 },
  damagedCorner: { position: 'absolute', width: 45, height: 45, right: -18, top: -18, backgroundColor: '#E6D9C1', transform: [{ rotate: '45deg' }] },
  damagedCorner2: { position: 'absolute', width: 38, height: 38, left: -16, bottom: -16, backgroundColor: '#E6D9C1', transform: [{ rotate: '45deg' }] },
  details: { width: '100%' },
  detailsTop: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  smallButton: { paddingHorizontal: 13, paddingVertical: 8, borderRadius: 10, backgroundColor: COLORS.panel2 },
  smallButtonAccent: { paddingHorizontal: 13, paddingVertical: 8, borderRadius: 10, backgroundColor: '#7650D8' },
  smallButtonText: { color: '#FFF', fontWeight: '800', fontSize: 12 },
  creditBox: { marginTop: 14, backgroundColor: COLORS.panel, borderRadius: 14, borderWidth: 1, borderColor: COLORS.line, padding: 12 },
  creditTitle: { color: '#FFF', fontWeight: '900', fontSize: 12 },
  creditText: { color: COLORS.muted, marginTop: 4, fontSize: 11, lineHeight: 16 },
  linkRow: { flexDirection: 'row', gap: 14, flexWrap: 'wrap', marginTop: 9 },
  link: { color: '#77B7FF', fontWeight: '800', fontSize: 11 },
});
