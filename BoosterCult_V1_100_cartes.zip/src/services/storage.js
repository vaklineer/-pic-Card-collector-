
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = '@boostercult/state/v1';

export const defaultState = {
  coins: 1500,
  collection: [],
  boostersOpened: 0,
  wins: 0,
  losses: 0,
};

export async function loadState() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    if (!raw) return defaultState;
    return { ...defaultState, ...JSON.parse(raw) };
  } catch {
    return defaultState;
  }
}

export async function saveState(state) {
  try {
    await AsyncStorage.setItem(KEY, JSON.stringify(state));
  } catch {
    // Prototype V1: on évite de bloquer l'UI si le stockage local échoue.
  }
}

export async function resetState() {
  await AsyncStorage.removeItem(KEY);
}
