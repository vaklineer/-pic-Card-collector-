
import { CARDS } from '../data/cards';
import { RARITIES, VARIANTS, CONDITIONS } from '../theme';

const weightedKey = (obj, allowed = null) => {
  const entries = Object.entries(obj).filter(([key]) => !allowed || allowed.includes(key));
  const total = entries.reduce((sum, [, value]) => sum + value.weight, 0);
  let roll = Math.random() * total;
  for (const [key, value] of entries) {
    roll -= value.weight;
    if (roll <= 0) return key;
  }
  return entries[entries.length - 1][0];
};

export const rollVariant = () => weightedKey(VARIANTS);
export const rollCondition = () => weightedKey(CONDITIONS);

export const rollCardByRarity = (forcedRarity = null) => {
  const rarity = forcedRarity || weightedKey(RARITIES);
  const pool = CARDS.filter((c) => c.rarity === rarity);
  return pool[Math.floor(Math.random() * pool.length)];
};

export const makeInstance = (baseCard, forced = {}) => {
  const variant = forced.variant || rollVariant();
  const condition = forced.condition || rollCondition();
  const serial = variant === 'numbered'
    ? `${String(Math.floor(Math.random() * 250) + 1).padStart(3, '0')}/250`
    : null;
  const value = Math.max(1, Math.round(
    baseCard.baseValue *
    RARITIES[baseCard.rarity].multiplier *
    VARIANTS[variant].multiplier *
    CONDITIONS[condition].multiplier
  ));
  return {
    instanceId: `${baseCard.id}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    cardId: baseCard.id,
    variant,
    condition,
    serial,
    value,
    obtainedAt: new Date().toISOString(),
  };
};

export const openBooster = () => {
  const pulls = [];
  for (let i = 0; i < 4; i += 1) {
    pulls.push(makeInstance(rollCardByRarity()));
  }
  // Cinquième carte: Rare ou mieux garantie.
  const guaranteed = weightedKey(RARITIES, ['rare', 'epic', 'legendary', 'cursed']);
  pulls.push(makeInstance(rollCardByRarity(guaranteed)));
  return pulls;
};

export const randomStat = () => ['aura','chaos','culot'][Math.floor(Math.random() * 3)];
