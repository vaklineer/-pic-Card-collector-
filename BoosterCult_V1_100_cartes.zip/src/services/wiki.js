
const pageCache = new Map();
const creditCache = new Map();

const cleanText = (html = '') => html
  .replace(/<[^>]*>/g, '')
  .replace(/&nbsp;/g, ' ')
  .replace(/&amp;/g, '&')
  .replace(/&#39;/g, "'")
  .replace(/&quot;/g, '"')
  .trim();

const api = async (url) => {
  const res = await fetch(url, {
    headers: { 'Api-User-Agent': 'BoosterCult/0.1 (prototype; Wikimedia attribution in-app)' },
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
};

export async function resolveWikipediaCard(card) {
  if (pageCache.has(card.id)) return pageCache.get(card.id);

  const queryUrl =
    `https://fr.wikipedia.org/w/api.php?action=query&format=json&origin=*` +
    `&prop=pageimages|info&inprop=url&pithumbsize=900&redirects=1&titles=${encodeURIComponent(card.wikiTitle)}`;

  let data = await api(queryUrl);
  let page = Object.values(data?.query?.pages || {})[0];

  // Si le titre seed n'existe pas exactement, on laisse Wikipédia chercher le meilleur article.
  if (!page || page.missing !== undefined) {
    const searchUrl =
      `https://fr.wikipedia.org/w/api.php?action=query&format=json&origin=*` +
      `&list=search&srlimit=1&srsearch=${encodeURIComponent(card.wikiTitle)}`;
    const found = await api(searchUrl);
    const title = found?.query?.search?.[0]?.title;
    if (title) {
      data = await api(
        `https://fr.wikipedia.org/w/api.php?action=query&format=json&origin=*` +
        `&prop=pageimages|info&inprop=url&pithumbsize=900&redirects=1&titles=${encodeURIComponent(title)}`
      );
      page = Object.values(data?.query?.pages || {})[0];
    }
  }

  let imageUrl = page?.thumbnail?.source || null;
  let imageFile = page?.pageimage || null;

  // Certains articles n'ont pas de miniature déclarée. Dans ce cas on cherche
  // directement un fichier libre sur Wikimedia Commons avec le même sujet.
  if (!imageUrl) {
    try {
      const commonsSearch =
        `https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*` +
        `&generator=search&gsrnamespace=6&gsrlimit=1&gsrsearch=${encodeURIComponent(page?.title || card.wikiTitle)}` +
        `&prop=imageinfo&iiprop=url&iiurlwidth=900`;
      const commonsData = await api(commonsSearch);
      const commonsPage = Object.values(commonsData?.query?.pages || {})[0];
      const imageInfo = commonsPage?.imageinfo?.[0];
      imageUrl = imageInfo?.thumburl || imageInfo?.url || null;
      imageFile = commonsPage?.title?.replace(/^File:/, '') || null;
    } catch {}
  }

  const result = {
    title: page?.title || card.wikiTitle,
    articleUrl: page?.fullurl || `https://fr.wikipedia.org/wiki/${encodeURIComponent(card.wikiTitle.replace(/ /g, '_'))}`,
    imageUrl,
    imageFile,
  };
  pageCache.set(card.id, result);
  return result;
}

export async function resolveCommonsCredit(imageFile) {
  if (!imageFile) return null;
  if (creditCache.has(imageFile)) return creditCache.get(imageFile);

  try {
    const title = imageFile.startsWith('File:') ? imageFile : `File:${imageFile}`;
    const url =
      `https://commons.wikimedia.org/w/api.php?action=query&format=json&origin=*` +
      `&prop=imageinfo&iiprop=url|extmetadata&titles=${encodeURIComponent(title)}`;
    const data = await api(url);
    const page = Object.values(data?.query?.pages || {})[0];
    const info = page?.imageinfo?.[0];
    const meta = info?.extmetadata || {};
    const result = {
      fileUrl: info?.descriptionurl || info?.url || null,
      artist: cleanText(meta.Artist?.value || meta.Credit?.value || 'Contributeur Wikimedia'),
      license: cleanText(meta.LicenseShortName?.value || meta.UsageTerms?.value || 'Licence indiquée sur Wikimedia Commons'),
      licenseUrl: meta.LicenseUrl?.value || null,
      attributionRequired: meta.AttributionRequired?.value !== 'false',
    };
    creditCache.set(imageFile, result);
    return result;
  } catch {
    return null;
  }
}
