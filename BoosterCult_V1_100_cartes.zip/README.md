# Booster Cult — Prototype V1

Prototype Android / Expo React Native d’un jeu de cartes à collectionner orienté boosters.

> **Nom provisoire** : “Booster Cult” peut être remplacé plus tard sans toucher à la logique du jeu.

## Ce qui est déjà dans cette V1

- **100 cartes seedées directement dans le code** (`src/data/cards.js`)
- Série 001 : **Le Grand Bazar**
- Visuels récupérés à l’exécution depuis **Wikipédia FR**, avec repli vers **Wikimedia Commons**
- Tentative de récupération des **crédits, auteur et licence** du fichier Commons
- 6 raretés :
  - Commune
  - Peu commune
  - Rare
  - Épique
  - Légendaire
  - Maudite
- 6 variantes indépendantes :
  - Standard
  - Holo
  - Full Art
  - Gold
  - Glitch
  - Numérotée /250
- 6 états physiques :
  - Impeccable
  - Quasi neuve
  - Bien conservée
  - Usée
  - Abîmée
  - Massacrée
- La **cote** dépend de la rareté + variante + état
- Le **gameplay ne dépend pas de la cote** : les stats Aura / Chaos / Culot restent celles de la carte
- Booster de 5 cartes avec **Rare ou mieux garantie**
- Album 100 cartes + recherche + filtres
- Sauvegarde locale via AsyncStorage
- Mini duel **3 manches** contre bot
- Crédits gagnés en duel
- Dos de carte dont l’usure augmente selon l’état
- Fiche carte avec lien vers l’article Wikipédia et, si trouvé, le fichier Commons / licence

## Répartition des 100 cartes

- 39 Communes
- 25 Peu communes
- 15 Rares
- 11 Épiques
- 7 Légendaires
- 3 Maudites

Les sujets couvrent objets du quotidien, animaux, France, technologie, événements historiques absurdes et quelques références volontairement plus dérangeantes.

## Build APK avec GitHub Actions

Le workflow est déjà inclus :

`.github/workflows/build-apk.yml`

1. Crée un nouveau dépôt GitHub.
2. Dézippe ce projet et envoie **le contenu du dossier** à la racine du dépôt.
3. Va dans **Actions**.
4. Ouvre **Build Android APK**.
5. Lance **Run workflow**.
6. Une fois terminé, télécharge l’artifact **BoosterCult-v1-APK**.

Le workflow :
- installe Node 22 ;
- installe Java 17 ;
- installe les dépendances ;
- génère le dossier Android avec Expo Prebuild ;
- exécute `assembleRelease` ;
- publie l’APK comme artifact GitHub.

## Build APK avec EAS (alternative)

Le projet contient aussi `eas.json`.

```bash
npm install
npm install -g eas-cli
eas login
eas build -p android --profile preview
```

Le profil `preview` sort un **APK**.

Le profil `production` est configuré en **AAB** pour une future publication Play Store :

```bash
eas build -p android --profile production
```

## Lancer en développement

```bash
npm install
npx expo start
```

## Structure

```text
App.js
src/
  components/
    CardView.js
  data/
    cards.js
  services/
    random.js
    storage.js
    wiki.js
  theme.js
.github/
  workflows/
    build-apk.yml
```

## Système de cote V1

La cote est volontairement simple pour cette première version :

`valeur de base × multiplicateur de rareté × multiplicateur de variante × multiplicateur d’état`

### État
- Impeccable : ×1,35
- Quasi neuve : ×1,16
- Bien conservée : ×1,00
- Usée : ×0,82
- Abîmée : ×0,62
- Massacrée : ×0,38

### Variante
- Standard : ×1
- Holo : ×1,55
- Full Art : ×2,2
- Gold : ×3,5
- Glitch : ×5
- Numérotée : ×8

La future V2 pourra remplacer cette cote théorique par une **cote marché dynamique** fondée sur les échanges entre joueurs.

## Wikimedia / licences

Cette V1 demande des images à Wikipédia et Wikimedia Commons. Le code essaye de remonter aux métadonnées du fichier Commons (`Artist`, licence, URL de licence et page du fichier).

**Important avant diffusion publique :**
- auditer les 100 visuels réellement résolus ;
- vérifier individuellement leurs licences ;
- conserver les attributions requises ;
- éviter de considérer “présent sur Wikipédia” comme synonyme de “libre de toute obligation”.

La fiche d’une carte contient déjà les liens nécessaires pour préparer ce contrôle.

## À faire après validation de cette V1

Les grosses briques naturelles suivantes sont :
- backend comptes joueurs ;
- inventaire serveur ;
- boosters journaliers ;
- échanges entre joueurs ;
- marché / cote réelle ;
- amis ;
- deck builder ;
- matchmaking ;
- extensions de 500+ cartes ;
- pipeline automatique Wikidata / Wikimedia pour générer de nouvelles cartes à valider ;
- animations de reveal premium ;
- sons / vibration ;
- vrais shaders holo/glitch ;
- authentification ;
- anti-triche.
