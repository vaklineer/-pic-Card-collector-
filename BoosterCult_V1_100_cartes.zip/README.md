# Booster Cult V2 — Série 001 : Le Grand Bazar

Cette V2 est une refonte mobile du prototype :

- cartes au vrai ratio TCG, plus aérées et lisibles ;
- navigation protégée par les safe areas Android (y compris barre 3 boutons) ;
- images chargées via l'API Wikipédia, avec repli automatique vers Wikimedia Commons et cache local ;
- 5 variantes visuellement et mécaniquement distinctes : Standard, Argent, Prisme, Galaxie, Aurore ;
- fiche plein écran au toucher avec source Wikipédia/Wikimedia, puissance, cote et état ;
- migration automatique des données enregistrées sous `@boostercult/state/v1` ;
- collection, boosters, état/grade, doublons et duel conservés/renforcés ;
- 100 cartes intégrées dans le code.

## Compilation Android

Le projet cible Expo SDK 57 / React Native 0.86 et conserve le package Android `com.boostercult.app`.

```bash
npm install
npx expo prebuild --platform android --clean --non-interactive
cd android
./gradlew assembleRelease
```

L'APK est généré dans `android/app/build/outputs/apk/release/`.

## Important pour le dépôt GitHub actuel

Le workflow déjà installé dans le dépôt GitHub décompresse actuellement `BoosterCult_V1_100_cartes.zip`.
Pour compiler cette V2 sans modifier le workflow, remplace simplement l'ancien ZIP par la copie de cette V2 portant le même nom.
